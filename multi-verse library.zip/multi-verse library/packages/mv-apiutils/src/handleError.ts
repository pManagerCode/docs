import { STATUS_CODES } from './constants';
import { HandleControllerErrorParams } from './types';

export const handleControllerError = ({
  error,
  controllerName,
  res,
  logger,
}: HandleControllerErrorParams) => {
  const statusCode = error.error.status || STATUS_CODES.INTERNAL_SERVER_ERROR;
  const statusMessage =
    error.error.statusText || `Unknown Error in ${controllerName}`;
  logger.error(error);
  res.status(statusCode).send(statusMessage);
};
