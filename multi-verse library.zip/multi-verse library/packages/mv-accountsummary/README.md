
# @mesh-tenant-multiverse-ui-common/mv-accountsummary

  

## Purpose

  

The `MVAccountSummary` component provides a account summary. It is built with GEL Next and styled using Tailwind CSS.

  

## Usage

  

To use the `MVAccountSummary` component, follow these steps:

  

1. Import the component in your file:

  

```jsx

import { MVAccountSummary } from  '@mesh-tenant-multiverse-ui-common/components';

```

  

2. Add the `MVAccountSummary` component to your JSX code and provide the necessary props:

  

```jsx

import  React, { useRef } from  'react';

import { MVAccountSummary } from  '@mesh-tenant-multiverse-ui-common/components';

  

return (

<MVAccountSummary
	header={<div>Header</div>}
	items={[]}
/>

);

};

  

export  default  MyComponent;

```

  

## Props

  

The `MVAccountSummary` component accepts the following props:

  

-  `header` (optional): header rendered as first section;

-  `items` (required): data of options;

  

## Example

  

Here's an example of how to use the `MVAutoComplete` component:

  

```jsx

import  React, { useRef } from  'react';

import  MVAccountSummary  from  '@mesh-tenant-multiverse-ui-common/components';

  

const  MyComponent = () => {

const  accountSummaryItems:  MVAccountSummaryItem[] = [{
	title:  'Current balance',
	content: `$100,0000.00`
}, {
	title:  'Available balance',
	content: `$100,0000.00`
}, {
	title:  'Currency',
	content:  'AUD',
}];
return (

<MVAccountSummary
	header={<div>Header</div>}
	items={accountSummaryItems}
/>

);

};

export  default  MyComponent;
```