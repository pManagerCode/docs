export {
  Resources,
  Actions,
  AUTHORISED_MSG,
  NOT_AUTHORISED_MSG,
} from './constants';
export { useAuthoriser, isUserAuthorised } from './useAuthoriser';
export type { AuthorisationOutcome } from './types';
