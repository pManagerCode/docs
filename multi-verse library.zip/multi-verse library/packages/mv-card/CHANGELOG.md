# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

### 🚀 Features

- added sample stories for the details & card packages ([9ef7bd3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9ef7bd395cff52395559ab23529426639ff925a4))

### 💥 Bug Fixes

- fixed the styling with mvaccount formatter story ([95a3935](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/95a39355f61a65bbc0fd37c0991fdc5d908c6e5a))

## [1.22.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.2...v1.22.0) (2024-11-13)

### 🚀 Features

- MVCard title conditional rendering added | ART-29128 ([8dae60e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8dae60e04b16f37d4f995d5cad1d7b8bf3ad03a9))

## [1.16.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.15.0...v1.16.0) (2024-11-04)

### 🚀 Features

- mvcard component updates | ART-29215 ([18f22d2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/18f22d236a49ed6755980cf1c6b15a47222f1915))
- mvcard style updates | ART-29215 ([154ab1c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/154ab1c33c6b40462312a756d7143758aaf6b4d7))

## [1.13.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.8...v1.13.0) (2024-11-01)

### 🚀 Features

- mvcard component migration | ART-29215 ([9d39cda](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9d39cda9a6a10b11ae741d2ed4c1f300d266028f))
- review comment fixes | ART-29215 ([8f70eb2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8f70eb22a0c099df635df2bd2a84c335a1220360))

## [1.10.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.9.0...v1.10.0) (2024-10-22)

### 🚀 Features

- component updateion | ART-28136 ([8c92281](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8c92281f2a764123117bba261294e71c43bf7f25))
- mvcard component | ART-28136 ([64a6b0e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/64a6b0eebe6649df67ecb40f1b5430c79c527480))
- mvcard component update and package-lock.json updates | ART-28136 ([10c0789](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/10c0789efe9a5886d6f4313c55b7f9964537d350))
- restructure of missing props | ART-28136 ([e3c1992](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e3c1992f9fda235094cc399b08c2025f0ca50026))
