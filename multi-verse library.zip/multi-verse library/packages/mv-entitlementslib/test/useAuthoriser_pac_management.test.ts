import { AUTHORISED_MSG, Resources } from '../src/constants';
import { Actions } from '../src/constants';
import { useAuthoriser } from '../src/useAuthoriser';

const token =
  'eyJhbGciOiJSUzM4NCIsImtpZCI6Im1TeWFxdThMM1JpeHJGNXpqRFhQcld5UXBEayIsInBpLmF0bSI6Im9rMXkifQ.eyJzY29wZSI6ImdhbGF4eSBvcGVuaWQiLCJhdXRob3JpemF0aW9uX2RldGFpbHMiOltdLCJjbGllbnRfaWQiOiI5MzVhY2YxZi00MzUyLTQ2MGYtYjgwYy00NmQ1YzJjM2JhNDAiLCJpc3MiOiJodHRwczovL29uZWFjY2Vzcy5zaXQuYXV0aC5ucC53ZXN0cGFjZ3JvdXAuY29tIiwianRpIjoiQjV6bFg0RUgxcFNGRTVGUGVJWlpJdTUxYXRkMXlxIiwiYnNiIjoiMDMyLTkwMCIsInN1YiI6IkYwNjg2MjAiLCJyb2xlIjpbIkEwMTRBNl9XMUNfQ0NNUF9lbmZvcmNlbWVudF9hY2xfc2l0IiwiQTAxNEE2LWdhbGF4eS1wYWMtbWFuYWdlbWVudCJdLCJlbXBsb3llZUlEIjoiRjA2ODYyMCIsIndiY19pYW1fdXNlcmlkIjoiRjA2ODYyMCIsImdpdmVuX25hbWUiOiJBbmluZGl0YSIsImZhbWlseV9uYW1lIjoiR2hvc2giLCJleHAiOjE3MzIyNDY4NTl9.A46BcNdj20-X4TfPUXXpbaHiFX5v0AfLklZbvXlIZ0GmwZwJDmRdgJj_-GvcOzAK5PtUcbRGdp_1UD6Jg1b2AHy1h8rALTotUdtlY1Dj63gaZTJj5Z_zkfVMTxoy5PtnhhliNWVrbSNkeBuc155q359HKe7P0f9mGhXs4Pv_E8FimnkNQF9E2yWR5RKtTO5jay4_G_k9MV9kKZfTdd-PFGK-eSkRQ-LEa4jPtmTZTC4WheQp64l-EL3AZVhCdmSMnshUeA-Mk7KbKmBPChzxTgV8LKCv7fPPobJee_PjhpsI5rKenET_Tm8I9HHK0Yj2qSUjgn_NpRhxUoX6zrWnzg';

// eslint-disable-next-line @typescript-eslint/no-unsafe-return
jest.mock('@mep-ui/framework', () => ({
  isLocalUrl: () => false,
}));

jest.mock('react-redux', () => ({
  useSelector: () => token,
}));

describe('useAuthoriser ', () => {
  // valid request
  describe('when token contains A014A6-galaxy-pac-management role (valid requests)', () => {
    test('VIEW should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('OVER_RIDE_CREDIT_INTEREST should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.OVER_RIDE_CREDIT_INTEREST
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    //addition permissions from service and operation role

    test('VIEW_ACCOUNTS should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_ACCOUNTS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('VIEW_TRANSACTIONS should return true ', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_TRANSACTIONS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('VIEW_PAYMENTS should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_PAYMENTS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('VIEW_ADVANCE_PAYMENT_TRANSACTIONS should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_ADVANCE_PAYMENT_TRANSACTIONS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string} , message: ${message}`    );
    });

    test('INITIATE_PAYMENT should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.INITIATE_PAYMENT
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('INITIATE_PAYMENT_RETURN should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.INITIATE_PAYMENT_RETURN
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('MANAGE_ACCOUNT_NAME should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.MANAGE_ACCOUNT_NAME
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });
  });
});
