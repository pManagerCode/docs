/* eslint no-console: off */
const fs = require('fs');
const cheerio = require('cheerio');
const readline = require('readline');

const { COMPONENT_NAME } = process.env;

/**
 *
 * @param {*} phrase  -It is the Regex pattern on which content will be selected from the file
 * @param {*} input -  It is the input file from which data will be read, in this case it will be CHANGELOG.md
 * @param {*} version  - Latest version of React Gel from lerna.json, as it is the source of truth
 */
const filterFile = (phrase, input, version) =>
  new Promise((resolve, reject) => {
    const majorVersion = parseInt(version.split('.')[0], 10);
    const lines = [];
    const rl = readline.createInterface({
      input: fs.createReadStream(input),
    });

    rl.on('line', line => {
      if (line.includes(phrase[0], 0) || line.includes(phrase[1], 0)) {
        const regex = /\[(.*?)\]/;
        const content = regex.exec(line)[1];
        const currentVersion = parseInt(content.split('.')[0], 10);
        // returning n,n-1 and n-2 versions of React Gel except the latest as that is already in build/docs/latest
        const isVersionListed =
          currentVersion === majorVersion ||
          currentVersion === majorVersion - 1 ||
          currentVersion === majorVersion - 2;

        if (content !== version && isVersionListed) {
          lines.push(content);
        }
      }
    });

    rl.on('close', () => resolve(lines));
    rl.on('error', err => reject(err));
  });

const buildPrevious = async version => {
  try {
    // Assuming the pattern will remain same '## [', read all previous versions from CHANGELOG
    const data = await filterFile(['## [', '# ['], './CHANGELOG.md', version);

    if (data) {
      const previousDir = `./build/previous`;

      if (!fs.existsSync(previousDir)) {
        fs.mkdirSync(previousDir);
      }

      const docPathPrevious = `${previousDir}/index.html`;

      let str = ``;
      data.map(ver => {
        str += `<li><a target="_blank" href="https://one.dev1.ui.westpac.com.au/library/docs/${COMPONENT_NAME}/${ver}/index.html">${ver}</a></li>`;
        return str;
      });

      fs.writeFile(
        docPathPrevious,
        `<!DOCTYPE html><html><head><meta http-equiv="refresh" />
        <link rel="stylesheet" href="https://one.dev1.ui.westpac.com.au/error/westpac/style/style-full.min.css" media="all">
        <link rel="stylesheet" href="https://one.dev1.ui.westpac.com.au/error/westpac/style/symbols-icons.data.svg.min.css" type="text/css" media="all"></link>
        <link rel="shortcut icon" href="https://one.dev1.ui.westpac.com.au/error/westpac/img/favicon.ico">

       </head>
        <body class='general'>
        <div class='wrapper'><noindex>
        <!-- global header -->
        <div class="header-wrapper">
            <header class="header">
                <!-- logo bar -->
                <div class="logo-bar">
                    <div class="header-logo logo-new">
                        <a href="https://www.westpac.com.au/" title="Westpac Banking Corporation">
                            <span class="logo icon-logo-wbc-sm hidden-xs" style="background-image: none;">
                                <!--?xml version="1.0" encoding="utf-8"?--><svg class="SVGInline-svg" style="width: auto;height: auto;" aria-labelledby="title-logo-wbc" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="69px" height="28px" viewBox="0 0 69 28" enable-background="new 0 0 69 28" xml:space="preserve">


                                <path d="M24.4 25L17.6 4.1C16.7 0.9 15 0 12.6 0H0c1 0.4 1.6 2.9 1.6 2.9l6.1 21c0.7 2.6 2.9 4 5.4 4h13.3C25.4 27.8 24.4 25 24.4 25" fill="#DA1710"></path>
                                <path d="M44.6 25l6.8-20.9C52.3 0.9 54 0 56.4 0H69c-1 0.4-1.6 2.9-1.6 2.9l-6.1 21c-0.7 2.6-2.9 4-5.4 4H42.6C43.6 27.8 44.6 25 44.6 25" fill="#DA1710"></path>
                                <rect x="27" width="15" height="28" fill="#DA1710"></rect>
                                </svg></span>
                        </a>
                    </div>
                </div>
            </header>
        </div>
        <!-- /global header -->
    </noindex>

        <div id='container' class='general'>
          <div class="column-container">
            <div class="container-fluid">
                 <div class="row">
                        <div class="col-sm-7 col-md-6 col-lg-5">
                            <div class="headers-text">
                                <h3 class="headers-headline">Previous versions of Gel</h3>
                            </div>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="bodycopy">
                            <p>Please select one of the links below:</p>
                        </div>
                        <div>
                        <ul class='lists lists-linklist'>
                        ${str}
                        </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>



        </div>

        </body></html>`,
        err => {
          if (err) {
            // console.error('error occurred :::', err);
            process.exit(-1); // fail the build
          }
        }
      );
    }
  } catch (err) {
    // console.log('following error occurred :::', err);
    process.exit(-1); // fail the build
  }
};

const buildLatestRedirect = version => {
  const latestDir = `./build/latest`;
  fs.mkdirSync(latestDir);
  const docPathLatest = `${latestDir}/index.html`;
  // console.log(`Running post-publish build ${docPathLatest} to redirect to /npm/docs/node-framework/${ver}/index.html`);
  fs.writeFile(
    `${docPathLatest}`,
    `<html><head><meta http-equiv="refresh" content="0;URL=/library/docs/${COMPONENT_NAME}/${version}/index.html"></head><body></body></html>`,
    err => {
      if (err) {
        // console.error('error occurred :::', err);
        process.exit(-1); // fail the build
      }
    }
  );
};

const cacheBustJsFiles = (file, version) => {
  fs.readFile(file, `utf-8`, (readErr, html) => {
    if (readErr) return;
    const $ = cheerio.load(html);
    $('script').each((i, element) => {
      const jsSrc = $(element).attr('src');
      if (jsSrc) {
        $(element).attr('src', `${jsSrc}?rev=${version}`);
      }
    });
    // write file
    fs.writeFile(file, $.html(), () => {});
  });
};

const processDocFiles = (version, buildNumber) => {
  const docDir = `./build/${version}/`;
  const docPreviewFile = `iframe.html`;
  const docMainFile = `index.html`;
  if (!fs.existsSync(docDir)) {
    throw new Error(`Error in processDocFiles: ${docDir} does not exist.`);
  }

  cacheBustJsFiles(docDir + docPreviewFile, `${version}.${buildNumber}`);
  cacheBustJsFiles(docDir + docMainFile, `${version}.${buildNumber}`);
};

const renameDocFiles = version => {
  // Rename story book docs folder, this assumes npm run build has occurred prior to executing this script
  const docTempDir = `./build/temp`;
  const docTargetDir = `./build/${version}`;
  fs.rename(docTempDir, docTargetDir, err => {
    if (err) {
      throw err;
    }
    console.log(`Storybook docs renamed from ${docTempDir} -> ${docTargetDir}`);

    // Ensure we cache burst js files
    processDocFiles(version, process.env.BUILD_NUMBER || 'local');
  });
};

module.exports = {
  buildLatestRedirect,
  buildPrevious,
  processDocFiles,
  renameDocFiles,
};
