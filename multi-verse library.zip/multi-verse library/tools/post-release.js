/* eslint no-console: off */
const { execSync } = require('child_process');

const {
  buildPrevious,
  renameDocFiles,
  buildLatestRedirect,
} = require('./publish-support');
const library = require('../packages/library/package.json');

const { DOCS_SKIP, DOCS_VERSION, BRANCH_TYPE } = process.env;

console.log(`Extracting required environment variables...
DOCS_SKIP: ${DOCS_SKIP}
BRANCH_TYPE: ${BRANCH_TYPE}
DOCS_VERSION: ${DOCS_VERSION}
`);

if (DOCS_SKIP === 'true') {
  execSync(`rm -rf ./build`);
} else {
  const version = library.version || DOCS_VERSION || '0.0.0';
  console.log(`Proposed version of the docs :: ${version}`);

  // Rename docs folder to a specific version
  renameDocFiles(version);

  // Update doc landing pages only on CI
  if (BRANCH_TYPE === 'master') {
    console.log(
      `Attempting to publish a stable version of the docs :: ${version}`
    );
    buildLatestRedirect(version);
    buildPrevious(version);
  }
}

execSync(`rm -rf ./.env`);
