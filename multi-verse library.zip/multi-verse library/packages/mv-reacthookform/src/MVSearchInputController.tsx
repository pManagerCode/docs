/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import {
  Control,
  Controller,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
} from 'react-hook-form';
import MVAutoComplete, {
  ListOption,
} from '../../mv-autocomplete/src/MVAutoComplete';

export type MVSearchInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  autoFocus?: boolean;
  placeholder: string;
  validationRules?: RegisterOptions;
  listOptions: ListOption[];
  renderOption?: (option: ListOption) => JSX.Element;
  renderValue?: (option: ListOption) => string;
  noOptionsMessage?: string;
  defaultInputs?: any;
  header: string;
};

function MVSearchInputController<T extends FieldValues>({
  fieldName,
  control,
  errors,
  autoFocus,
  placeholder,
  validationRules,
  listOptions,
  renderOption,
  renderValue,
  defaultInputs,
  header,
}: MVSearchInputControllerProps<T>) {
  const errorMessage = (errors[fieldName]?.message as string) ?? '';
  return (
    <Controller
      name={fieldName}
      control={control as Control<FieldValues>}
      rules={validationRules}
      render={({ field: { onChange, onBlur, value, ...rest } }) => (
        <MVAutoComplete
          {...rest}
          defaultInputOption={
            defaultInputs?.account && {
              ...defaultInputs?.account,
            }
          }
          defaultInputValue={
            value?.id && value?.name ? `${value.name} - ${value.id}` : ''
          }
          listOptions={listOptions}
          setSearchItem={() => {
            onChange(value);
          }}
          onBlur={() => {
            onBlur();
          }}
          isError={!!errorMessage}
          header={header}
          helpText=""
          errorMessage={errorMessage}
          autoFocus={autoFocus}
          renderOption={renderOption}
          optionsMaxHeight={320}
          renderValue={renderValue}
          placeholder={placeholder}
        />
      )}
    />
  );
}

export default MVSearchInputController;
