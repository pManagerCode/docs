# @mesh-tenant-multiverse-ui-common/mv-detailsection

## Purpose

The `MVDetailSection` component provides a detail section that displays the paired label and value. It is built with React and styled using Tailwind CSS.

## Usage

To use the `MVDetailSection` component, follow these steps:

1. Import the component in your file:

   ```jsx
   import MVDetailSection from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
   ```

2. Add the `MVDetailSection` component to your JSX code and provide the necessary props:

   ```jsx
   import React, { useRef } from 'react';
   import MVDetailSection from '@mesh-tenant-multiverse-ui-common/mv-detailsection';

   const MyComponent = () => {
     const detailItems = [
       {
         label: 'Title',
         value: 'Title you want to show',
       },
       {
         label: 'Description',
         value: 'description you want to show',
       },
     ];

     return <MVDetailSection data={detailItems} />;
   };

   export default MyComponent;
   ```

## Props

The `MVDetailSection` component accepts the following props:

- `heading` (optional): A string that specifies the header for the detail section.
- `data` : array of {label: string; value: string} to display in this section
- `withTopBorder` (optional): Boolean to show the top border.
- `withBottomBorder` (optional): Boolean to show the bottom border.

## Example

Here's an example of how to use the `MVDetailSection` component:

```jsx
import React, { useRef } from 'react';
import MVDetailSection from '@mesh-tenant-multiverse-ui-common/mv-detailsection';

const MyComponent = () => {
  const detailItems = [
    {
      label: 'Title',
      value: 'Title you want to show',
    },
    {
      label: 'Description',
      value: 'description you want to show',
    },
  ];

  return <MVDetailSection heading="From" data={detailItems} withTopBorder />;
};

export default MyComponent;
```
