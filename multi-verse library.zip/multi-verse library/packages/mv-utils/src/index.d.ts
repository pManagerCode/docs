import { Ref } from 'react';
export { Settings as LuxonSettings } from 'luxon';

/**
 * Type definition for the screen
 */

export function scrollToTop(): void;

/**
 * Type definition for the debounce
 */

export function debounce(
  callback: () => void,
  time: number,
  finalCallback: () => void
): () => void;

/**
 * Type definition for the dateTime
 */

export function getFormattedDateTime(
  dateTimeIsoString?: string,
  timeFormat?: string
): string;

export function getFormattedDate(
  dateTimeIsoString?: string,
  dateFormat?: string,
  displayStyle?: 'date-time' | 'date-time-zone'
): string;

export function getEndDateExclusive(date: string): string | null;

export function getStartDateInclusive(date: string): string | null;

export function convertSydneyLocalTimeToUtc(data: string): string | null;

/**
 * Type definition for the crypto
 */

export const base64ToArrayBuffer: (base64: string) => ArrayBufferLike;
export const generateKeyFromBase64: (
  base64: string,
  KeyUsage: KeyUsage[]
) => Promise<CryptoKey>;
export const decryptDataChunkFromString: (
  encryptedChunkString: string,
  key: CryptoKey
) => Promise<unknown>;

/**
 * Type definition for the format
 */

export const formatToTwoDecimals: (input: string) => string;
export function currencyFormatter(num?: number, locale?: string): string;
export function formatWithEllipsis(str?: string, maxLength?: number): string;

export function formatCurrency(value: number | ''): string;
export function formatPercentage(rate: number): string;
export function formatBSB(id: string, index: number): string;
export const formatBSBFromAccNo: (
  accountNo: string | undefined,
  bsbLength?: number
) => string;

/**
 * Type definition for the ref
 */

export const mergeRefs: <T>(refs: Ref<T>[]) => (value: T) => void;

/**
 * Type definition for the urlUtils
 */

export const getURLParams: () => string;
export const getAppUrlWithParams: (newUrl: string, appName?: string) => string;
export const isStaffPortal: () => boolean;

export const formatCurrencyString: (input: string) => string;
export const parseCurrencyString: (input: string) => string;

/**
 * Type definition for appCorrelationId
 */
type SetAppCorrelationId = (id: string) => void;
export const useAppCorrelationId: (
  setAppCorrelationId: SetAppCorrelationId
) => string;
