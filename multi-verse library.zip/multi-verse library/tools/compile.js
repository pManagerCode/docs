const path = require('path');
const { last } = require('lodash');
const { spawn } = require('child_process');

const { argv } = require('yargs')
  .alias('c', 'component')
  .alias('d', 'current-directory');

console.log(`\n\u001b[33;1mPreparing package for compilation\u001b[0m`);

const { INIT_CWD } = process.env;
const currentWorkingDirectory = argv.currentDirectory || INIT_CWD;
const componentFromPath = last(currentWorkingDirectory.split(path.sep));

const componentName = argv.component || componentFromPath;

console.log(
  `Attempting to compile \u001b[37;1m${
    componentName
  }\u001b[0m @ \u001b[35;1m${currentWorkingDirectory}\u001b[0m`
);

const webpack = spawn('node', [path.resolve(__dirname, './buildPackage.js')], {
  cwd: currentWorkingDirectory,
  stdio: [0, 1, 2],
});

webpack.on('exit', code => process.exit(code));
