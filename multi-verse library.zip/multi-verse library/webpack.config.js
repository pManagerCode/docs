/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const webpack = require('webpack');
const { camelCase } = require('lodash');
const CopyPlugin = require('copy-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
// const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
// const CircularDependencyPlugin = require('circular-dependency-plugin');

const pkgPath = process.cwd();
const pkg = require(path.resolve(pkgPath, './package.json'));

// if (pkg.main) {
const outputMain = path.parse(pkg.main);
const outputPath = outputMain.path || 'dist';
const outputName = outputMain.name || 'bundle';
const outputFile = outputMain.base || 'bundle.js';
const outputPathLocal = path.resolve(pkgPath, outputPath);
const babelConfigFile = path.join(__dirname, './babel.config.json');

module.exports = {
  mode: 'production',
  entry: './src/index.ts',
  resolve: {
    extensions: ['.ts', '.tsx', '.js', '.jsx', '.json'],
  },
  output: {
    path: outputPathLocal,
    filename: outputFile,
    library: {
      name: camelCase(outputName),
      type: 'umd',
    },
    globalObject: 'this',
  },
  devtool: 'source-map',
  stats: {
    colors: true,
    reasons: true,
  },
  externals: ['lodash', 'react'],
  module: {
    rules: [
      {
        test: /\.(ts|tsx|js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: { extends: babelConfigFile },
        },
      },
      {
        test: /\.css$/i,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[ext]',
              outputPath: 'fonts/',
            },
          },
        ],
      },
    ],
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify('production'),
      __webpack_share_scopes__: '__webpack_share_scopes__',
    }),
    new CleanWebpackPlugin(),
    new CopyPlugin({
      patterns: [
        {
          from: './src/index.d.ts',
          to: path.parse(pkg.types).base,
        },
      ],
    }),
    // new BundleAnalyzerPlugin({
    //   analyzerMode: 'disabled',
    //   generateStatsFile: true,
    //   statsFilename: '../bundle-stats.json',
    // }),
    // new CircularDependencyPlugin({
    //   // exclude detection of files based on a RegExp
    //   exclude: /a\.js|node_modules/,
    //   // add errors to webpack instead of warnings
    //   failOnError: false,
    //   // set the current working directory for displaying module paths
    //   cwd: process.cwd(),
    // }),
  ],
};
// }
