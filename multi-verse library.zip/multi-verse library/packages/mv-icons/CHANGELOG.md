# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.44.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.44.0...v1.44.1) (2025-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-icons

## [1.44.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.43.0...v1.44.0) (2025-01-13)

### 🚀 Features

- add RightArrow icon | ART-31841 ([b86e89f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b86e89f59fec9bf6693ead9ecf59c1c79792d463))
- update RightArrow icon to use inline src | ART-31841 ([2c47ca6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2c47ca6bfbc1c8777638cc14414a761bfa882626))

## [1.34.9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.8...v1.34.9) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-icons

## [1.34.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.7...v1.34.8) (2024-12-11)

### 💥 Bug Fixes

- update MVIcon props and add PayTo logo | ART-15769 ([6cffa62](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6cffa6213099e79944e3fa477a8da1b5e247cfb4))

## [1.34.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.1...v1.34.2) (2024-12-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-icons
