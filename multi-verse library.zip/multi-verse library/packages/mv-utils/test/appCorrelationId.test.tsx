import { renderHook } from '@testing-library/react';
import { useAppCorrelationId } from '../src/appCorrelationId';
import { v4 as uuid } from 'uuid';

jest.mock('uuid');

describe('useAppCorrelationId', () => {
  let setAppCorrelationId: jest.Mock;

  beforeEach(() => {
    setAppCorrelationId = jest.fn();
    (uuid as jest.Mock).mockReturnValue('test-uuid');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should generate a new app correlation ID and call setAppCorrelationId', () => {
    renderHook(() => useAppCorrelationId(setAppCorrelationId));

    expect(setAppCorrelationId).toHaveBeenCalledWith('test-uuid');
  });

  it('should call window.setUserDataForAppd if it exists', () => {
    window.setUserDataForAppd = jest.fn();

    renderHook(() => useAppCorrelationId(setAppCorrelationId));

    expect(window.setUserDataForAppd).toHaveBeenCalledWith({
      appCorrelationId: 'test-uuid',
    });

    delete window.setUserDataForAppd;
  });

  it('should not throw if window.setUserDataForAppd does not exist', () => {
    expect(() => {
      renderHook(() => useAppCorrelationId(setAppCorrelationId));
    }).not.toThrow();
  });
});
