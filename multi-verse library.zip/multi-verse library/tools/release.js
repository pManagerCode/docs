/* eslint no-console: off */
const { spawnSync } = require('child_process');

const { BRANCH_TYPE: branchType, BUILD_NUMBER: buildNumber } = process.env;

const isCI = buildNumber || false;

const publish = command => {
  const { output } = spawnSync(command, { encoding: 'utf-8', shell: true });

  /**
   * NOTE:  An unfortunate side-effect of this kind of invocation
   *        is that the output of the command is not piped immediately
   *        to stdio so when parsing below and writing to stdio
   *        there is a noticeable lag which might seem a bit unresponsive
   */
  const pipe = output
    // eslint-disable-next-line no-extra-boolean-cast
    .reduce((acc, current) => (!!current ? [...acc, current] : acc), [])
    .join('')
    /**
     * NOTE:  Some beautification done to retain some of the console colours
     *        Strictly unnecessary!!!
     */
    .replace(/\bcli\b/gm, '\x1b[35mcli\x1b[0m')
    .replace(/\binfo\b/gm, '\x1b[32minfo\x1b[0m')
    .replace(/\bnotice\b/gm, '\x1b[36mnotice\x1b[0m')
    .replace(/\bversioning\b/gm, '\x1b[35mversioning\x1b[0m')
    .replace(/\bsuccess\b/gm, '\x1b[32m\x1b[1msuccess\x1b[0m');

  console.log(pipe);
};

// Only run publish on CI
if (isCI) {
  switch (branchType) {
    case 'master':
      // CI master build
      console.log(
        `Executing lerna (${branchType}) publish, and publish docs to (/latest)\n`
      );

      publish(`lerna publish`);

      break;

    default:
      // CI feature build
      console.log(
        `Executing lerna (${branchType}) publish, and publish docs to (/alpha.${buildNumber})\n`
      );

      publish(
        `lerna publish --canary --force-publish --preid alpha.${buildNumber} --no-commit-hooks --no-git-tag-version --no-push`
      );

      break;
  }
} else {
  // Local build
  console.log(`Executing lerna (local) version, dry run only\n`);

  publish(`lerna version --no-commit-hooks --no-git-tag-version --no-push`);
}
