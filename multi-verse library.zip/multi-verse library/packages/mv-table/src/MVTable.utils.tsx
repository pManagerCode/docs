import { useState, useEffect } from 'react';
import {
  generateKeyFromBase64,
  decryptDataChunkFromString,
} from '../../mv-utils/src';
import { LicenseManager } from 'ag-grid-enterprise';
import { useSelector } from 'react-redux';

type State = {
  global: {
    config: {
      galaxyTable: {
        key: string;
        lic: string;
      };
    };
  };
};

export const useSetAgGridLic = () => {
  const [isSetMVTableKey, setIsSetMVTableKey] = useState(false);

  const mvTableKey = useSelector(
    (state: State) => state?.global?.config?.galaxyTable?.key
  ) as unknown as string;
  const mvTableLic = useSelector(
    (state: State) => state?.global?.config?.galaxyTable?.lic
  ) as unknown as string;

  useEffect(() => {
    const setLic = async () => {
      const key = await generateKeyFromBase64(decodeURIComponent(mvTableKey), [
        'decrypt',
      ]);
      const lic = await decryptDataChunkFromString(
        decodeURIComponent(mvTableLic),
        key
      );
      LicenseManager.setLicenseKey(lic);
      setIsSetMVTableKey(true);
    };

    if (mvTableKey && mvTableLic) {
      setLic();
    }
  }, [mvTableKey, mvTableLic]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!isSetMVTableKey) {
        console.error("Couldn't initialize MVTable with provided key!!!");
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [isSetMVTableKey]);

  return isSetMVTableKey;
};
