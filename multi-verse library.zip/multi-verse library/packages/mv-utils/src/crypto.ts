export const base64ToArrayBuffer = (base64: string) => {
  const binaryString = window.atob(base64);
  const length = binaryString.length;
  const bytes = new Uint8Array(length);
  for (let i = 0; i < length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  return bytes.buffer;
};

export const generateKeyFromBase64 = async (
  base64: string,
  KeyUsage: KeyUsage[]
) => {
  const arrayBuffer = base64ToArrayBuffer(base64);
  const key = await crypto.subtle.importKey(
    'pkcs8',
    arrayBuffer,
    {
      name: 'RSA-OAEP',
      hash: 'SHA-256',
    },
    true,
    KeyUsage
  );

  return key;
};

export const decryptDataChunkFromString = async (
  encryptedChunkString: string,
  key: CryptoKey
) => {
  let decryptText = '';
  const encryptedChunkBase64s = encryptedChunkString.split('|');

  for (const base64Chunk of encryptedChunkBase64s) {
    const encryptedChunk = base64ToArrayBuffer(base64Chunk);
    const decryptedChunk = await crypto.subtle.decrypt(
      { name: 'RSA-OAEP' },
      key,
      encryptedChunk
    );
    decryptText += new TextDecoder().decode(decryptedChunk);
  }
  const licObj = decryptText?.length && JSON.parse(decryptText);
  if (licObj?.spaName) {
    // prevent reuse of key across other apps
    if (
      window.location.href.includes(`/${licObj.spaName}`) ||
      window.location.hostname === 'localhost'
    ) {
      return licObj.license;
    }
  }
  return '';
};
