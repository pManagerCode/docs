import * as React from 'react';

export interface HelloWorldProps {
  /**
   * Accepts a string which is displayed by the component
   */
  text: string;
}

export const HelloWorld: React.FC;
