# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.21.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.20.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.20.0...v1.20.1) (2024-11-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.17.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.7...v1.12.8) (2024-10-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.6...v1.12.7) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.1...v1.12.2) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.0...v1.12.1) (2024-10-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.11.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))
