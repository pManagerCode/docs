# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.47.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.47.0...v1.47.1) (2025-01-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

### 🚀 Features

- added sample stories for the details & card packages ([9ef7bd3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9ef7bd395cff52395559ab23529426639ff925a4))
- integrated storybook with webpack, added required config files ([b789dc6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b789dc66e72d9661796b48b977fe319ed1186ed4))

### 💥 Bug Fixes

- fixed the styling with mvaccount formatter story ([95a3935](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/95a39355f61a65bbc0fd37c0991fdc5d908c6e5a))
- updated redux-actions version to fix version conflict errros ([1348945](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/13489457c9570372bae77eb466bcae950eeb276f))

## [1.39.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.3...v1.39.4) (2024-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.34.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.6...v1.34.7) (2024-12-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.34.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.5...v1.34.6) (2024-12-11)

### 💥 Bug Fixes

- label undefined error of account formatter | ART-32246 ([ee7aa85](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ee7aa85557ffcf08061b768303b75b0009248c06))

## [1.34.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.0...v1.34.1) (2024-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.33.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.33.1...v1.33.2) (2024-11-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.32.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.31.1...v1.32.0) (2024-11-26)

### 🚀 Features

- refactor mv-account-formatter ([4593d95](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4593d956ef9c11b50d5633ecbefde9ed1989afee))
- refactor mv-account-formatter ([3911025](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/39110254bf2bf4a5c5784fdd4dd0d2908433799a))

## [1.30.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.30.1...v1.30.2) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.30.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.30.0...v1.30.1) (2024-11-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.30.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.29.0...v1.30.0) (2024-11-22)

### 🚀 Features

- extend mv-accountformatter ([d06d453](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d06d453870568c09394ca5ccea8fedf64a15bfa8))

## [1.25.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.1...v1.25.2) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-accountformatter

## [1.25.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.24.0...v1.25.0) (2024-11-18)

### 🚀 Features

- migrate mv-accountformatter ([9e8f3cb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9e8f3cb3e93483daebf56cc659667913f16a9a70))
- migrate mv-accountformatter ([aba825a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/aba825a30e2c9c09e251d4eb2dd048cae3c5148b))
- migrate mv-accountformatter ([69b154f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/69b154f04c9dc547fc5affde968298ab29b3924f))

## [1.10.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.9.0...v1.10.0) (2024-10-22)

### 🚀 Features

- **ui-galaxy:** add acount formatter | ART-24665 ([6263fc6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6263fc669a00198fdc5ea08ff3537237b26a6218))
