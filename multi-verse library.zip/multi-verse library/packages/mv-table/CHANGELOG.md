# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.40.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.40.1...v1.40.2) (2024-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.34.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.6...v1.34.7) (2024-12-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.33.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.33.0...v1.33.1) (2024-11-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.30.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.30.1...v1.30.2) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.25.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.2...v1.25.3) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.25.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.1...v1.25.2) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.15.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.14.0...v1.15.0) (2024-11-04)

### 🚀 Features

- update to ts | ART-15347 ([4f5dba5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4f5dba5234cda618bad6b9596bdb1c30cec383fc))

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

### 🚀 Features

- add ag-grid | ART-15347 ([4d7a0ce](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4d7a0cec74717df4226dbbb8eaa4a9057c1d5168))
