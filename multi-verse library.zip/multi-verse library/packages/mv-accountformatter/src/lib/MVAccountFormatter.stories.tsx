import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import MVAccountFormatter from '../MVAccountFormatter';
import { MVAccountFormatterProps } from '../MVAccountFormatter';

// default export with component metadata
export default {
  title: 'Components/MVAccountFormatter',
  component: MVAccountFormatter,
  tags: ['autodocs'],
  argTypes: {
    details: {
      control: 'object',
      description: 'Details to be displayed in the formatter',
    },
  },
} as Meta<typeof MVAccountFormatter>;

// template for creating stories
const Template: StoryFn<typeof MVAccountFormatter> = args => (
  <MVAccountFormatter {...args} />
);

// ----------------------------- with basic list layout -----------------------------
export const ListLayout = Template.bind({});
ListLayout.args = {
  primary: true,
  details: ['Account Summary', '123-456 123456789'],
} as MVAccountFormatterProps;

// ----------------------------- with styled layout -----------------------------
export const StyledListLayout = Template.bind({});
StyledListLayout.args = {
  details: [
    {
      variant: 'text',
      value: 'Account Summary',
      className: 'font-bold text-lg p-1 text-left underline',
    },
    {
      variant: 'text',
      value: '123-456 123456789',
      className: 'p-1  text-left',
    },
    { variant: 'text', value: 'Type: Savings', className: 'p-1 text-left' },
    {
      variant: 'text',
      value: 'Current Balance: $2000',
      className: 'p-1 text-left',
    },
  ],
} as MVAccountFormatterProps;

// ----------------------------- with two column list layout -----------------------------
export const TwoColumnListLayout = Template.bind({});
TwoColumnListLayout.args = {
  details: [
    {
      label: 'Name:',
      value: 'John Doe',
      className:
        'm-0 overflow-hidden break-words font-semibold typography-body-10',
      variant: 'text',
    },
    {
      label: (
        <div className="flex gap-3">
          <span>PayID name:</span>
          <span> </span>
        </div>
      ),
      value: 'JohnD',
      className:
        'm-0 overflow-hidden break-words font-normal text-muted typography-body-10',
      variant: 'text',
    },
    {
      label: 'PayID:',
      value: 'john.doe@example.com',
      className:
        'm-0 overflow-hidden break-words font-normal text-text typography-body-10',
      variant: 'text',
    },
  ],
  className: 'flex space-x-4',
} as MVAccountFormatterProps;
