# @mesh-tenant-multiverse-ui-common/mv-accountformatter

## Purpose

The `mv-accountformatter` package now serves as the core utility package for all other component packages. It exposes a few core functions that are for internal consumption only & some basic reusable functions that can be used across (including micro-apps).

In the interest of abbreviation for the scope of this document, the contents of the ESDocs comments are reused here.

!!! note

    All exports are exposed out of `AppWrapper` and not to be used directly from this package.

---

## Usage

To use the `MVAccountFormatter` component, follow these steps:

1. Import the component in your file:

   ```jsx
   import MVAccountFormatter from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';
   ```

2. Add the `MVAccountFormatter` component to your JSX code and provide the necessary props:

   ```jsx
   import React, { useRef } from 'react';
   import MVAccountFormatter from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';

     return (
       <MVAccountFormatter/>
     );
   };

   export default MyComponent;
   ```

## Props

The `MVAccountFormatter` component accepts the following props:

- `details` (required): list of values to format;

## Example

Here's an example of how to use the `MVAccountFormatter` component:

```jsx
import React, { useRef } from 'react';
import MVAccountFormatter from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';

export type AccountDetailsItem = {
  value: string;
  /**  Apply a style class to override the default label style
   * e.g: className: 'm-0 font-semibold text-muted'
   * */
  className?: string;
} & (
  | {
      variant: 'accessory-icon';
      /** left accessory icon */
      accessory: React.ReactNode;
      /** label is required if the accessory is set.*/
      label: string;
    }
  | {
      variant: 'text';
      label?: string;
    }
);

export type MVAccountFormatterProps = {
  details: string[] | AccountDetailsItem[] ;
};

// default
const MyComponent = () => {


  return (
    <MVAccountFormatter
            details={['Bob Marley','bob@bob.com','Email Address']}
          />
  );
};

export default MyComponent;

// with custom styles
const MyStyledComponent = () => {
  return (
    <MVAccountFormatter
            details={[{
                label:'name',
                value:'Bob Marley',
                className:'m-0 overflow-hidden break-words font-semibold typography-body-11'
            }]}
          />
  );
};

export default MyStyledComponent;
```
