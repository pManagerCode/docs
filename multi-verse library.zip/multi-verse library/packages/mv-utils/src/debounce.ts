export const debounce = (
  callback: () => void,
  time: number,
  finalCallback: () => void
): (() => void) => {
  let setTimeoutId: ReturnType<typeof setTimeout> | undefined;

  return () => {
    if (!setTimeoutId) {
      callback();
      setTimeoutId = setTimeout(() => {
        finalCallback();
        clearTimeout(setTimeoutId);
      }, time);
    }
  };
};
