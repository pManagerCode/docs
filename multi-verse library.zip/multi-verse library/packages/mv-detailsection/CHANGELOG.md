# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.47.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.47.1...v1.47.2) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-detailsection

## [1.47.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.47.0...v1.47.1) (2025-01-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-detailsection

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

### 🚀 Features

- added sample stories for the details & card packages ([9ef7bd3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9ef7bd395cff52395559ab23529426639ff925a4))

### 💥 Bug Fixes

- fixed the styling with mvaccount formatter story ([95a3935](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/95a39355f61a65bbc0fd37c0991fdc5d908c6e5a))

## [1.39.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.4...v1.39.5) (2024-12-18)

### 💥 Bug Fixes

- account detail page the line above the date opened has unexpected space | ART-37396 ([c1348c4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c1348c4b44006fc3d7cf36affad71f9f292ca4c4))

## [1.39.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.1...v1.39.2) (2024-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-detailsection

## [1.34.10](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.9...v1.34.10) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-detailsection

## [1.24.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.23.1...v1.24.0) (2024-11-15)

### 🚀 Features

- allow developers to add a link button to the header of the MVDetailSection component ([3a66ab8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3a66ab875864c55337be4cafd0ed98e5e47ba12b))

## [1.14.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.13.0...v1.14.0) (2024-11-03)

### 🚀 Features

- Detail section component update and merge with master branch and resolved conflicts| ART-16972 ([f8f8f28](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f8f8f281e9024b6370d48b1a1b2dfd08448d0479))

## [1.11.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- detail section update using jsx instead of tsx| ART-16969 ([855b357](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/855b3572b2e1ddca84f1898d7f9df5bc1cbb9bd2))

## [1.10.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.9.0...v1.10.0) (2024-10-22)

### 🚀 Features

- detail section update component name| ART-16969 ([c678c44](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c678c4473c72fccddec3ec333ec3f60724731868))

## [1.9.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.8.0...v1.9.0) (2024-10-22)

### 🚀 Features

- common detail section componennt update | ART-16969 ([1e09be0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1e09be0b1cb8c32103a37a4a4827fc8253766949))
- detail section update according to PR review 02| ART-16969 ([1762ab5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1762ab5a42b0464dfa3af15ca3fa9eac2b154c3a))
