import * as React from 'react';

export type MVCardProps = {
  children: React.ReactNode;
  title?: string;
  template?: string;
  subtitle?: string;
  bottomDivider?: boolean;
};

export const MVCard: React.FC<MVCardProps>;
