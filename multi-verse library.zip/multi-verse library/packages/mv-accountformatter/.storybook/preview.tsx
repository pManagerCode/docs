// .storybook/preview.ts
import '!style-loader!css-loader!postcss-loader!tailwindcss/tailwind.css';
import type { Preview } from '@storybook/react';
import * as DocBlock from '@storybook/blocks';
import React from 'react';

export const preview: Preview = {
  parameters: {
    docs: {
      page: () => (
        <>
          <DocBlock.Title />
        </>
      ),
    },
    actions: { argTypesRegex: '^on[A-Z].*' },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
  },
};
