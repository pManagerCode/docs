import { DateTime, Settings } from 'luxon';
import { AEDT, AEST } from './constants';

export { Settings as LuxonSettings };

export const getFormattedDateTime = (
  dateTimeIsoString?: string,
  timeFormat: string = 'h:mma'
) => {
  const currentTime = dateTimeIsoString
    ? DateTime.fromISO(dateTimeIsoString).setZone('Australia/Sydney')
    : DateTime.utc().setZone('Australia/Sydney');
  const isDST = currentTime.isInDST;
  const zoneName = isDST ? AEDT : AEST;

  const formattedTime = currentTime.toFormat(timeFormat).toLowerCase();

  const formattedDateTime = `${currentTime.toFormat(
    'd LLL yyyy'
  )}, ${formattedTime} (${zoneName})`;

  return formattedDateTime;
};

export const getFormattedDate = (
  dateTimeIsoString?: string,
  dateFormat: string = 'd LLL yyyy',
  displayStyle: 'date-time' | 'date-time-zone' = 'date-time-zone'
) => {
  const currentTime = dateTimeIsoString
    ? DateTime.fromISO(dateTimeIsoString).setZone('Australia/Sydney')
    : DateTime.utc().setZone('Australia/Sydney');
  const isDST = currentTime.isInDST;
  const zoneName = isDST ? AEDT : AEST;

  const formattedDateTime = `${currentTime.toFormat(dateFormat)}${displayStyle === 'date-time-zone' ? ` (${zoneName})` : ''}`;

  return formattedDateTime;
};

export const getEndDateExclusive = (date: string): string | null => {
  const zone = 'Australia/Sydney';
  let endDate = DateTime.fromISO(date, { zone });
  endDate = endDate.plus({ days: 1 });
  endDate = endDate.startOf('day');
  return endDate.toUTC().toISO();
};

export const getStartDateInclusive = (date: string): string | null => {
  const zone = 'Australia/Sydney';
  let startDate = DateTime.fromISO(date, { zone });
  startDate = startDate.startOf('day');
  return startDate.toUTC().toISO();
};

export function convertSydneyLocalTimeToUtc(date: string): string | null {
  const zone = 'Australia/Sydney';
  const newDate = date.replace(' ', 'T');
  const dateTime = DateTime.fromISO(newDate, { zone });
  return dateTime.toUTC().toISO();
}
