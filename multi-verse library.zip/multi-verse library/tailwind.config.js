import { withGEL } from '@westpac/ui/tailwind';
import { join } from 'path';

/** @type {import('tailwindcss').Config} */
const config = withGEL({
  content: [
    join(__dirname, './src/**/*.{js,ts,jsx,tsx,mdx}'),
    join(__dirname, './node_modules/@westpac/ui/src/**/*.{js,ts,jsx,tsx,mdx}'),
  ],
  // options: {
  //   brandFonts: {
  //     src: '/fonts',
  //     /** takes a single brand string e.g. 'wbc' or an array of brands.
  //   If no brands are specified will import all brands by default */
  //     brands: ['wbc'],
  //   },
  // },
});

export default config;
