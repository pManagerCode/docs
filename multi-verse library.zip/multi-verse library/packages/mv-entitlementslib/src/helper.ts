import { jwtDecode } from './jwt';
import { RoleBaseAuthorisationModel, RoleBaseJwtModel } from './types';

export function parseRoleBasedModel(token: string): RoleBaseAuthorisationModel {
  const jwtModel = jwtDecode<RoleBaseJwtModel>(token);
  const roleModel: RoleBaseAuthorisationModel = { roles: [] };
  if (Array.isArray(jwtModel.role)) {
    roleModel.roles = jwtModel.role.map(v => v.toLowerCase());
  } else {
    roleModel.roles = jwtModel.role.toLowerCase().split(',');
  }
  return roleModel;
}
