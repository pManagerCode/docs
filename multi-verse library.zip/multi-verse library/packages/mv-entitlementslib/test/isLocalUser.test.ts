import {
  AUTHORISED_MSG,
  AUTHORISATION_REQUEST_SKIPPED,
  Resources,
} from '../src/constants';
import { Actions } from '../src/constants';
import { isUserAuthorised } from '../src/useAuthoriser';

// eslint-disable-next-line @typescript-eslint/no-unsafe-return
jest.mock('@mep-ui/framework', () => ({
  isLocalUrl: () => true,
}));

jest.mock('react-redux', () => ({
  useSelector: jest
    .fn()
    .mockReturnValueOnce({
      loggedInUserRole: ['agent'],
    })

    .mockReturnValueOnce({}),
}));

// valid request
describe('Local role configuration  ', () => {
  describe('when Agent role is configured locally (valid requests)', () => {
    test('VIEW_ACCOUNTS should return true', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.VIEW_ACCOUNTS
      );

      expect(message).toEqual(AUTHORISED_MSG);
      expect(authorised).toBe(true);
      console.log(
        `authorised: ${authorised as unknown as string}, message: ${message}`
      );
    });
  });

  describe('when no role is configured locally (valid requests)', () => {
    test('VIEW_ACCOUNTS should return true', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.VIEW_ACCOUNTS
      );

      expect(message).toEqual(AUTHORISATION_REQUEST_SKIPPED);
      expect(authorised).toBe(true);
      console.log(
        `authorised: ${authorised as unknown as string}, message: ${message}`
      );
    });
  });
});
