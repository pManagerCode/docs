import { DatePicker, Field } from '@westpac/ui';
import React from 'react';

export type MVDateRangePickerProps = {
  heading?: string;
};
export default function MVDateRangePicker({ heading }: MVDateRangePickerProps) {
  return (
    <>
      {heading}
      <div className="flex gap-3">
        <div className="pb-2">
          <Field label="Select from">
            <DatePicker />
          </Field>
        </div>
        <div className="pb-2">
          <Field label="Select to">
            <DatePicker />
          </Field>
        </div>
      </div>
    </>
  );
}
