useAuthoriser: the interface to entitlement library.

useAuthoriser = (
resource: Resources,
actions: Actions
): AuthorisationOutcome

export enum Actions {
VIEW_ACCOUNTS = 'viewAccounts',
VIEW_TRANSACTIONS = 'viewTransactions',
VIEW_PAYMENTS = 'viewPayments',
INITIATE_PAYMENT = 'initiatePayment',
INITIATE_TRANSFER = 'initiateTransfer',
INITIATE_PAYMENT_RETURN = 'initiatePaymentReturn',
VIEW_BENEFICIARIES = 'viewBeneficiaries',
...
}

export enum Resources {
ACCOUNTS = 'account',
TRANSACTIONS = 'transaction',
...
}

export type AuthorisationOutcome = {
authorised: boolean;
message: string;
}

Usage - Refer to unit tests for more usage examples

import { authoriser, isUserAuthorised } from '@mesh-a014a6/components';
import { Resources, Roles , Actions} from '@mesh-a014a6/components';

const { authorised, message } = useAuthoriser(Resources.ACCOUNTS, Actions.INITIATE_PAYMENT)

const { authorised, message } = isUserAuthorised(Resources.ACCOUNTS, Actions.INITIATE_PAYMENT)
