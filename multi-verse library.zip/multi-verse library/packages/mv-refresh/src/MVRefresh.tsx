/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
import React, { useState, forwardRef, useImperativeHandle } from 'react';
import { getFormattedDateTime, debounce } from '../../mv-utils/src';
// @ts-ignore
import { RefreshIcon } from '@westpac/ui/icon';

export type MVRefreshProps = {
  onRefresh: () => void;
  disabled?: boolean;
};

export type MVRefreshHandle = {
  refreshDateTime: () => void;
};

const MVRefresh = forwardRef<MVRefreshHandle, MVRefreshProps>(
  ({ onRefresh, disabled }, ref) => {
    const [currentTime, setCurrentTime] = useState(getFormattedDateTime);
    const [isButtonDisabled, setIsButtonDisabled] = useState(disabled);

    useImperativeHandle(ref, () => ({
      refreshDateTime: () => {
        setCurrentTime(getFormattedDateTime());
      },
    }));

    const handleOnclick = () => {
      if (!isButtonDisabled) {
        setIsButtonDisabled(true);

        setCurrentTime(getFormattedDateTime());
        onRefresh();
      }
    };

    const enableRefreshWidget = () => {
      setIsButtonDisabled(false);
    };

    const debouncedHandleClick = debounce(
      handleOnclick,
      500,
      enableRefreshWidget
    );

    return (
      <button
        className={`flex items-center justify-start border-none pt-2 pl-0 bg-transparent cursor-pointer self-start ${disabled ? 'cursor-not-allowed' : ''}`}
        disabled={isButtonDisabled || disabled}
        onClick={debouncedHandleClick}
        type="button"
      >
        <RefreshIcon className="-mb-1 mr-0.5 mb-0" size="xsmall" />
        <p className="m-0">Last refreshed {currentTime}</p>
      </button>
    );
  }
);

export default MVRefresh;
