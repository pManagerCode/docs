# MVTable Component

## Installation

```
npm install @mesh-tenant-multiverse-ui-common
```

## Usage

```
import { MVTable } from '@mesh-tenant-multiverse-ui-common/components';

exprot default function MyTable = () => {
  ...
  return (
      <MVTable
        rowData={sortedList}
        defaultColumnDef={defaultColumnDef}
        columnDefs={columnDefs}
        enableCellTextSelection
        onCellClicked={onCellClicked}
        onColumnPinned={onColumnPinned}
        id="payment-list-mvtable"
        noRowMessage={noRowMessage}
      />
    );
}

```

## How to set AG Grid license key

### Step1: Generate the crypto key and encrypt your AGGrid License

1. Update licenseGen.js to add your SPA and AGGrid License, eg: secret.spaName & secret.license
2. Copy and Paste the contents of licenseGen.js to Chrome -> DevTools -> Console prompt to run it

Take note of the values of key & lic in console log as you would need to set in your app-config as follows

```
  "mvTable": {
    "key": KEY_VALUE
    "lic": LIC_VALUE
  }
```

### Step2: Add crypto key and encrypted license to the app config

Add the following block to your SPA app-config files. You need to add to all environments:

eg: galaxy-singlepageapplication/env/local/app-config.json

Do the same for all environments - local, dev1, sit1, uat1, svp1 & prod. If staff access is supported do for staff settings too as applicable.

```
"mvTable": {
  "key": "XXXXXXXX",
  "lic": "XXXXXXXX"
}
```

NOTE: lic is an encrypted & stringified JSON object in following format:

```
{
    spaName: 'galaxy', // set this to your SPA componentName
    license: 'agGrid_LICENSE_STRING', // use as-is, don't reformat
}
```

### Step3: Decrypt the license key with crypto key and add it to the AG Grid LicenseManager

Add the following code into your WithMFE HOC for respective MFE to read the license from the Global Store, decrypt it and set in the agGrid License Manager.

```
import { LicenseManager } from 'ag-grid-enterprise';

const mvTableKey = useGlobalSelector(
  (state) => state?.global?.config?.mvTable?.key
);
const mvTableLic = useGlobalSelector(
  (state) => state?.global?.config?.mvTable?.lic
);

useEffect(() => {
  const setLic = async () => {
    const key = await generateKeyFromBase64(
      decodeURIComponent(mvTableKey),
      ['decrypt']
    );
    const lic = await decryptDataChunkFromString(
      decodeURIComponent(mvTableLic),
      key
    );
    LicenseManager.setLicenseKey(lic);
    setIsSetMVTableKey(true);
  };

  if (mvTableKey && mvTableLic) {
    setLic();
  }
}, [mvTableKey, mvTableLic]);
```
