import React, { ReactNode } from 'react';
export const spaceSize = 8;

type MVTableWrapperProps = {
  children: ReactNode;
};

const MVTableWrapper = ({ children }: MVTableWrapperProps) => (
  <div className="w-full">
    <style>{`
      .ag-cell,
      .ag-header-cell-label {
        font-size: 13px;
      }

      .ag-aria-description-container {
        display: none;
      }

      .ag-cell {
        line-height: 20px;
      }

      .ag-header-cell,
      .ag-cell {
        padding-top: ${spaceSize}px;
        padding-right: ${spaceSize / 2}px;
        padding-bottom: ${spaceSize}px;
        padding-left: ${spaceSize / 2}px;
      }

      .ag-header-cell {
        align-items: flex-start;
      }

      .ag-header {
        background: transparent;
        border-bottom: ${spaceSize / 4}px solid var(--color-hero);
      }

      .ag-pinned-left-header,
      .ag-pinned-right-header,
      .ag-root-wrapper {
        border: none;
      }

      .ag-header-cell:hover .ag-header-cell-resize {
        display: flex;
      }

      .ag-header-cell-resize {
        display: none;
      }

      .ag-header-icon {
        margin-top: ${spaceSize / 4}px;
        margin-right: ${spaceSize / 2}px;
      }

      .ag-icon {
        color: var(--color-text);
      }

      .ag-sort-indicator-icon {
        margin-top: ${spaceSize / 4}px;
      }

      .ag-cell.ag-cell-last-left-pinned:not(.ag-cell-range-right):not(
          .ag-cell-range-single-cell
        ),
      .ag-cell.ag-cell-first-right-pinned:not(.ag-cell-range-left):not(
          .ag-cell-range-single-cell
        ) {
        border-left: none;
        border-right: none;
      }

      .ag-pinned-left-cols-container .highlight-row::before,
      .ag-center-cols-container .highlight-row::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 5px;
        background-color: var(--color-primary);
        z-index: 100;
      }

      .has-pinned-left .ag-center-cols-container .highlight-row::before {
        display: none;
      }

      .ag-row {
        background-color: var(--color-white);
      }

      .ag-row:hover {
        background-color: var(--color-light);
      }

      .ag-header-group-cell-label,
      .ag-header-cell-label {
        align-items: flex-start;
      }

      .right-aligned-header {
        text-align: right;
      }

      .right-aligned-header .ag-header-cell-label {
        justify-content: flex-end;
      }

      .ag-cell-label-container {
        align-items: flex-start;
      }

      .right-aligned-amount-cell,
      .right-aligned-cell {
        text-align: right;
      }

      .right-aligned-cell .ag-cell-value {
        margin-right: ${spaceSize * 2}px;
      }

      .ag-tab.ag-tab-selected {
        border: none;
      }

      input.ag-input-field-input.ag-text-field-input,
      .ag-wrapper.ag-picker-field-wrapper,
      .ag-wrapper.ag-input-wrapper.ag-radio-button-input-wrapper {
        box-shadow: none;
      }

      input.ag-input-field-input.ag-text-field-input:focus,
      .ag-wrapper.ag-input-wrapper.ag-radio-button-input-wrapper:active {
        box-shadow: none;
      }

      .ag-button.ag-standard-button.ag-filter-apply-panel-button {
        font-size: 14px;
        color: var(--color-text);
        border-color: var(--color-heading);
        line-height: 21px;
        padding: ${spaceSize / 2}px ${spaceSize}px;
      }

      .default-header {
        color: var(--color-text);
        line-height: 20px;
        font-weight: 600;
        word-spacing: 9999px;
      }

      .default-cell {
        color: var(--color-text);
        line-height: 20px;
      }

      .overflow-visible-cell .ag-cell-value {
        overflow: visible;
      }

      .ag-menu.ag-ltr.ag-popup-child {
        background-color: #fff;
        border-radius: ${spaceSize * 0.375}px;
        overflow: hidden;
        outline: none;
        box-shadow: 0 ${spaceSize * 0.75}px ${spaceSize * 1.5}px
          rgba(0, 0, 0, 0.175);
        padding: ${spaceSize}px;
        width: ${spaceSize * 16}px;
        border: none;
      }

      .ag-menu-list.ag-focus-managed {
        padding: 0;
      }

      .ag-menu-list.ag-focus-managed .action-button:focus {
        outline: ${spaceSize / 4}px solid var(--input-color-border-outline);
        outline-offset: ${spaceSize * 0.375}px;
      }

      .ag-menu-list.ag-focus-managed .action-button:focus,
      .ag-menu-list.ag-focus-managed .action-button:hover {
        background-color: #f2f4f7;
      }

      .ag-menu-list.ag-focus-managed
        .action-button
        .ag-menu-option-part.ag-menu-option-text {
        padding: ${spaceSize / 2}px ${spaceSize}px;
        height: ${spaceSize * 3.5}px;
        line-height: 20px;
      }

      .ag-menu-list.ag-focus-managed .action-button .ag-menu-option-icon,
      .ag-menu-list.ag-focus-managed .action-button .ag-menu-option-shortcut,
      .ag-menu-list.ag-focus-managed
        .action-button
        .ag-menu-option-popup-pointer {
        display: none;
      }

      .ag-theme-alpine {
        --ag-selected-tab-underline-color: var(--color-heading);
        --ag-input-focus-border-color: var(--color-heading);
        --ag-checkbox-checked-color: var(--color-heading);
      }
    `}</style>
    {children}
  </div>
);

export default MVTableWrapper;
