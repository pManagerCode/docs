import * as React from 'react';

export type MVIconsProps = {
  height?: number;
  width?: number;
  name: string;
};

export const MVIcons: React.FC<MVIconsProps>;
