import { Button, Grid, GridItem, Heading } from '@westpac/ui';
import React from 'react';

export type MVDetailSectionProps = {
  heading?: string;
  data: { label: string; value: string | JSX.Element | null | undefined }[];
  withTopBorder?: boolean;
  withBottomBorder?: boolean;
  linkAction?: {
    id: string;
    name: string;
    text: string;
    action: () => void;
  };
};

function MVDetailSection({
  heading,
  data,
  withTopBorder,
  withBottomBorder,
  linkAction,
}: MVDetailSectionProps) {
  const filteredData = data.filter(item => item.value != null);
  if (filteredData.length === 0) return null;

  return (
    <>
      {heading && (
        <GridItem
          className={
            withTopBorder
              ? 'w-full py-2.5 border-t border-border'
              : 'w-full py-2.5'
          }
          span={12}
        >
          <Grid>
            <GridItem span={linkAction != null ? 10 : 12}>
              <Heading tag="h2" className="text-heading" size={7}>
                {heading}
              </Heading>
            </GridItem>
            {linkAction != null && (
              <GridItem span={2} className="text-right">
                <Button
                  id={linkAction.id}
                  name={linkAction.name}
                  look="link"
                  size="small"
                  onClick={() => linkAction.action()}
                >
                  {linkAction.text}
                </Button>
              </GridItem>
            )}
          </Grid>
        </GridItem>
      )}
      {filteredData.map(({ label, value }) => (
        <React.Fragment key={label}>
          <GridItem className="pb-2.5" span={4}>
            <label className="font-semibold text-text !m-0">{label}</label>
          </GridItem>
          <GridItem className="pb-2.5 break-words" span={8}>
            <p>{value}</p>
          </GridItem>
        </React.Fragment>
      ))}
      {withBottomBorder ? (
        <GridItem
          className="p-0 m-0 border-b border-border h-fit"
          span={12}
        ></GridItem>
      ) : (
        ''
      )}
    </>
  );
}
export default MVDetailSection;
