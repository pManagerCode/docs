/* eslint-disable @typescript-eslint/no-explicit-any */
/* This file polyfill the type declaraion for the follow module as mep-ui has not yet provided */
declare module '@mep-ui/framework' {
  const isLocalUrl: any; // no type declaration in @mep-ui/framework
  const isStaffUrl: any; // no type declaration in @mep-ui/framework
  const useGlobalSelector: any; // no type declaration in @mep-ui/framework
  const getOidcAccessTokenSlice: any; // no type declaration in @mep-ui/framework
  const setAppCorrelationId: any; // no type declaration in @mep-ui/framework
  const getConfig: any; // no type declaration in @mep-ui/framework
}
