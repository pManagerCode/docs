# core-ui-core

This library was generated with [Nx](https://nx.dev).

## Running lint

Run `nx lint core-ui-core` to execute the lint via [ESLint](https://eslint.org/).
