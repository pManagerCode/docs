import { ColDef, Column, IRowNode } from 'ag-grid-community';
import { AgGridReactProps } from 'ag-grid-react';
import { Ref, SyntheticEvent } from 'react';
export * from 'ag-grid-community';
export * from 'ag-grid-enterprise';
export * from 'ag-grid-react';
export { Settings as LuxonSettings } from 'luxon';

import React, { ReactNode } from 'react';
import {
  Control,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormTrigger,
} from 'react-hook-form';

export type MVInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id: string;
  label: string;
  hintText?: string;
  validationRules?: RegisterOptions;
  maximumLength?: number;
  footerAddon?: ReactNode;
  withFooter?: boolean;
  inputType?: string;
  placeholder?: string;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
};

export const MVInputController: <T extends FieldValues>(
  props: MVInputControllerProps<T>
) => React.ReactElement;

export type MVTextareaControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id: string;
  label: string;
  hintText?: string;
  validationRules?: RegisterOptions;
  maximumLength?: number;
  footerAddon?: ReactNode;
  withFooter?: boolean;
  inputType?: string;
};

export const MVTextareaController: <T extends FieldValues>(
  props: MVTextareaControllerProps<T>
) => React.ReactElement;

/**
 * Type definition for the MVRefresh component
 */

export type MVRefreshProps = {
  /**
   * Function to call when the refresh action is triggered
   */
  onRefresh: () => void;

  /**
   * Boolean to disable the refresh button
   */
  disabled?: boolean;
};

export type MVRefreshHandle = {
  /**
   * Function to refresh the current date and time
   */
  refreshDateTime: () => void;
};

export const MVRefresh: React.ForwardRefExoticComponent<
  React.PropsWithoutRef<MVRefreshProps> & React.RefAttributes<MVRefreshHandle>
>;

export type MVCardProps = {
  children: React.ReactNode;
  title?: string;
  template?: string;
  subtitle?: string;
  bottomDivider?: boolean;
};

export const MVCard: React.FC<MVCardProps>;

export type MVDetailSectionProps = {
  heading?: string;
  data: { label: string; value: string | JSX.Element | null | undefined }[];
  withTopBorder?: boolean;
  withBottomBorder?: boolean;
  linkAction?: {
    text: string;
    action: () => void;
  };
};

export const MVDetailSection: React.FC<MVDetailSectionProps>;

export type ListOption = {
  name: string;
  id: string;
  entityName?: string;
  accountType?: string;
  payeeType?: string;
  domestic?: {
    accountName?: string;
  };
};

export interface MVAutoCompleteProps {
  defaultInputValue: string;
  listOptions: ListOption[];
  setSearchItem: (value: ListOption) => void;
  onBlur: () => void;
  isError: boolean;
  autoFocus?: boolean;
  errorMessage: string;
  header: string;
  helpText: string;
  renderOption?: (option: ListOption) => JSX.Element;
  renderValue?: (option: ListOption) => string;
  optionsMaxHeight?: number;
  isIconVisible?: boolean;
  maxVisibleOptions?: number;
  defaultInputOption?: ListOption;
  placeholder?: string;
  renderOptionOnHover?: (option: ListOption) => JSX.Element;
  isAdditionalError?: boolean;
}

export const MVAutoComplete: React.FC<MVAutoCompleteProps>;

export type MVCurrencyControllerProps<T extends FieldValues> = {
  id: string;
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  validationRules?: RegisterOptions;
  trigger: UseFormTrigger<T>;
  disabled?: boolean;
};

export const MVCurrencyController: <T extends FieldValues>(
  props: MVCurrencyControllerProps<T>
) => React.ReactElement;

export type MVSelectControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id?: string;
  label: string;
  validationRules?: RegisterOptions;
  options: Array<{ id: string; label: string; name: string }>;
  disabled?: boolean;
};

export const MVSelectController: <T extends FieldValues>(
  props: MVSelectControllerProps<T>
) => React.ReactElement;

export type TableData = { [key: string]: unknown };

export type ActionButtonPropsType = {
  api: {
    contextMenuFactory: {
      showMenu: (
        node: IRowNode<TableData>,
        column: Column<TableData>,
        value: string,
        event: SyntheticEvent
      ) => void;
    };
  };
  node: IRowNode<TableData>;
  column: Column<TableData>;
};

export const ActionButton: React.FC<ActionButtonPropsType>;

export type MVTablePropsType = AgGridReactProps & {
  noRowMessage: string;
  rowData: TableData[];
  defaultColumnDef: ColDef;
  height?: number;
};

export const MVTable: React.FC<MVTablePropsType>;

export const useSetAgGridLic: () => boolean;

export type AccountDetailsItem = {
  value: string;
  className?: string;
} & (
  | {
      variant: 'accessory-icon';
      accessory: React.ReactNode;
      hint: string;
      label: string;
    }
  | {
      variant: 'text';
      label?: string;
    }
);

export type MVAccountFormatterProps = {
  details: string[] | AccountDetailsItem[];
};

export const MVAccountFormatter: React.FC<MVAccountFormatterProps>;

export type MVAccountSummaryItem = {
  title: string;
  content: React.ReactNode | string;
  status?: string;
  statusColor?: 'success' | 'hero' | 'warning' | 'danger';
  maxWidth?: number;
  minWidth?: number;
};

export type MVAccountSummaryProps = {
  header?: React.ReactNode;
  items: MVAccountSummaryItem[];
  error?: React.ReactNode;
};

export const MVAccountSummary: React.FC<MVAccountSummaryProps>;

export type MVLoaderProps = {
  iconSize?: 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
  color?: 'white' | 'black';
};

export const MVLoader: React.FC<MVLoaderProps>;

export type MVIconsProps = {
  width?: number;
  height?: number;
  name: string;
};

export const MVIcons: React.FC<MVIconsProps>;

export type MVSearchInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  autoFocus?: boolean;
  placeholder: string;
  validationRules?: RegisterOptions;
  listOptions: ListOption[];
  renderOption?: (option: unknown) => JSX.Element;
  renderValue?: (option: unknown) => string;
  noOptionsMessage?: string;
  defaultInputs?: unknown;
  header: string;
};
export const MVSearchInputController: <T extends FieldValues>(
  props: MVSearchInputControllerProps<T>
) => React.ReactElement;
/**
 * ==============================================================
 * ================== MV-ENTITLEMENTSLIB ========================
 * ==============================================================
 */

declare const AUTHORISED_MSG = 'You are authorised.';
declare const NOT_AUTHORISED_MSG = 'You do not have sufficient permission.';
declare enum Resources {
  ACCOUNTS = 'account',
  TRANSACTIONS = 'transaction',
  CUSTOMER = 'customer',
  PAC = 'PAC',
}
declare enum Actions {
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  INITIATE_PAYMENT = 'initiatePayment',
  INITIATE_TRANSFER = 'initiateTransfer',
  INITIATE_PAYMENT_RETURN = 'initiatePaymentReturn',
  VIEW_BENEFICIARIES = 'viewBeneficiaries',
  OVER_RIDE_CREDIT_INTEREST = 'overrideCreditInterest',
  VIEW_DEFAULT_PERMISSIONS = 'viewDefaultPermissions',
  VIEW = 'view',
  OPEN_ACCOUNT = 'openAccount',
  CLOSE_ACCOUNT = 'closeAccount',
  BLOCK_ACCOUNT = 'blockAccount',
  UNBLOCK_ACCOUNT = 'unblockAccount',
  BLOCK_CUSTOMER = 'blockCustomer',
  UNBLOCK_CUSTOMER = 'unblockCustomer',
  AUTHORISE_PAYMENT = 'authorisePayment',
  AUTHORISE_TRANSFER = 'authoriseTransfer',
  CREATE_USER = 'createUser',
  AUTHORISE_USER = 'authoriseUser',
  MANAGE_ACCOUNT_NAME = 'manageAccountName',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
}

type AuthorisationOutcome = {
  authorised: boolean;
  message: string;
};

declare const useAuthoriser: (
  resource: Resources,
  action: Actions
) => AuthorisationOutcome;

declare const isUserAuthorised: (
  resource: Resources,
  action: Actions
) => AuthorisationOutcome;

export {
  AUTHORISED_MSG,
  Actions,
  AuthorisationOutcome,
  NOT_AUTHORISED_MSG,
  Resources,
  isUserAuthorised,
  useAuthoriser,
};

/**
 * ==============================================================
 * ================== MV-UTILS ==================================
 * ==============================================================
 */

/**
 * Type definition for the mv-utils
 */

/**
 * Type definition for the screen
 */

export function scrollToTop(): void;

/**
 * Type definition for the debounce
 */

export function debounce(
  callback: () => void,
  time: number,
  finalCallback: () => void
): () => void;

/**
 * Type definition for the dateTime
 */

export function getFormattedDateTime(
  dateTimeIsoString?: string,
  timeFormat?: string
): string;

export function getFormattedDate(
  dateTimeIsoString?: string,
  dateFormat?: string,
  displayStyle?: 'date-time' | 'date-time-zone'
): string;

export function getEndDateExclusive(date: string): string | null;

export function getStartDateInclusive(date: string): string | null;

export function convertSydneyLocalTimeToUtc(data: string): string | null;

/**
 * Type definition for the crypto
 */

export const base64ToArrayBuffer: (base64: string) => ArrayBufferLike;
export const generateKeyFromBase64: (
  base64: string,
  KeyUsage: KeyUsage[]
) => Promise<CryptoKey>;
export const decryptDataChunkFromString: (
  encryptedChunkString: string,
  key: CryptoKey
) => Promise<unknown>;

/**
 * Type definition for the format
 */

export const formatToTwoDecimals: (input: string) => string;
export function currencyFormatter(num?: number, locale?: string): string;
export function formatWithEllipsis(str?: string, maxLength?: number): string;
export function formatCurrency(value: number | ''): string;
export function formatPercentage(rate: number): string;
export function formatBSB(id: string, index: number): string;
export function formatBSBFromAccNo(
  accountNo: string | undefined,
  bsbLength?: number
): string;

/**
 * Type definition for the ref
 */

export const mergeRefs: <T>(refs: Ref<T>[]) => (value: T) => void;

/**
 * Type definition for the urlUtils
 */

export const getURLParams: () => string;
export const getAppUrlWithParams: (newUrl: string, appName?: string) => string;
export const isStaffPortal: () => boolean;

/**
 * Type definition for the format
 */

export const formatCurrencyString: (input: string) => string;
export const parseCurrencyString: (input: string) => string;

/**
 * Type definition for appCorrelationId
 */
type SetAppCorrelationId = (id: string) => void;
export const useAppCorrelationId: (
  setAppCorrelationId: SetAppCorrelationId
) => string;
