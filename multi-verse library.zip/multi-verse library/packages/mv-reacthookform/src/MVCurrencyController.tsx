import { Input, InputGroup } from '@westpac/ui';
import React, {
  ClipboardEvent,
  CompositionEvent,
  SyntheticEvent,
  useRef,
  useState,
} from 'react';
import {
  Control,
  Controller,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormTrigger,
} from 'react-hook-form';

import { formatCurrencyString, mergeRefs } from '../../mv-utils/src';

export type MVCurrencyControllerProps<T extends FieldValues> = {
  id: string;
  fieldName: Path<T>;
  control: Control<FieldValues>;
  errors: FieldErrors<T>;
  validationRules?: RegisterOptions;
  trigger: UseFormTrigger<T>;
  disabled?: boolean;
};

const invalidValueMessage =
  'Enter an amount greater than 0, up to two decimal places.';

const validateCurrencyNumber = (value: string) => {
  const num = Number(value);
  const isNaN = Number.isNaN(num);
  if (isNaN || !value) return invalidValueMessage;
  const digitsAfterDecimal = value.split('.')[1]?.length;
  if (digitsAfterDecimal > 2 || num <= 0) return invalidValueMessage;
  return true;
};

const rules = {
  required: invalidValueMessage,
  validate: validateCurrencyNumber,
};

const numberFormatRegex = /^\d*(\.\d*)?$/;

type OnChange = (event: React.ChangeEvent<HTMLInputElement>) => void;

function MVCurrencyController<T extends FieldValues>({
  id,
  fieldName,
  control,
  errors,
  trigger,
  validationRules,
  disabled,
}: MVCurrencyControllerProps<T>) {
  const [isComposing, setIsComposing] = useState(false);
  const [isFocus, setIsFocus] = useState(false);
  const latestValidValue = useRef('');
  const inputRef = useRef<HTMLInputElement>();

  const handleCompositionStart = () => setIsComposing(true);
  const updatedRules = {
    ...rules,
    ...validationRules,
  };

  const handleCompositionEnd = (
    event: CompositionEvent<HTMLInputElement>,
    onChange: OnChange
  ) => {
    const {
      value: currentValue,
      selectionStart,
      selectionEnd,
    } = event.currentTarget;
    setIsComposing(false);
    if (numberFormatRegex.test(currentValue)) {
      latestValidValue.current = currentValue;
      onChange(currentValue);
    } else {
      onChange(latestValidValue.current);
      requestAnimationFrame(() => {
        if (
          inputRef.current &&
          selectionStart !== null &&
          selectionEnd !== null
        ) {
          inputRef.current.selectionStart =
            selectionStart -
            (currentValue.length - latestValidValue.current.length);
          inputRef.current.selectionEnd =
            selectionEnd -
            (currentValue.length - latestValidValue.current.length);
        }
      });
    }
  };

  const errorMessage = (errors[fieldName]?.message as string) ?? '';
  const invalid = Boolean(errors[fieldName]?.message);

  const handleOnChange = (event: SyntheticEvent<HTMLInputElement>) => {
    const {
      value: currentValue,
      selectionStart,
      selectionEnd,
    } = event.currentTarget;

    if (!isComposing) {
      if (numberFormatRegex.test(currentValue)) {
        latestValidValue.current = currentValue;
      } else {
        requestAnimationFrame(() => {
          if (
            inputRef.current &&
            selectionStart !== null &&
            selectionEnd !== null
          ) {
            inputRef.current.selectionStart =
              selectionStart -
              (currentValue.length - latestValidValue.current.length);
            inputRef.current.selectionEnd =
              selectionEnd -
              (currentValue.length - latestValidValue.current.length);
          }
        });
        return latestValidValue.current;
      }
    }

    return currentValue;
  };

  const handleOnPaste = (event: ClipboardEvent<HTMLInputElement>) => {
    const pastedData = event.clipboardData.getData('text');
    if (!numberFormatRegex.test(pastedData)) {
      event.preventDefault();
    }
  };

  const handleOnFocus = () => setIsFocus(true);

  const handleOnBlur = () => {
    setIsFocus(false);
    // With mode onBlur, any action that causes losing focus on field, like clicking on Submit button, will trigger the validation on the form. At that time, all fields are valid, therefore, the previous error message will disappear and shift the position of Submit button. The event onClick is targeting on old position of Submit button but now that position has no button, that's why we need to click the submit button twice!
    // So I added setTimeout here to trigger the onBlur validation manually, ensuring the handleSubmit can be triggered before the UI shift.
    setTimeout(() => trigger(fieldName), 150);
  };

  return (
    <Controller
      name={fieldName}
      control={control}
      rules={updatedRules}
      render={({ field: { ref, value, onChange, ...rest } }) => (
        <div>
          <div>
            <InputGroup
              label="Amount"
              tag="fieldset"
              errorMessage={errorMessage}
              size="small"
              before="AUD"
              width={10}
              instanceId={id}
            >
              <Input
                {...rest}
                disabled={disabled}
                className="focus:outline-2 focus:outline-data-d-tint focus:outline-offset-3"
                invalid={invalid}
                ref={mergeRefs([inputRef, ref])}
                onBlur={handleOnBlur}
                value={isFocus ? value : formatCurrencyString(value)}
                onChange={(event: SyntheticEvent<HTMLInputElement>) =>
                  onChange(handleOnChange(event))
                }
                onFocus={handleOnFocus}
                onPaste={(event: ClipboardEvent<HTMLInputElement>) =>
                  handleOnPaste(event)
                }
                onCompositionStart={handleCompositionStart}
                onCompositionEnd={(event: CompositionEvent<HTMLInputElement>) =>
                  handleCompositionEnd(event, onChange)
                }
              />
            </InputGroup>
          </div>
        </div>
      )}
    />
  );
}

MVCurrencyController.defaultProps = {
  validationRules: rules,
};

export default MVCurrencyController;
