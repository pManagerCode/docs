declare const AUTHORISED_MSG = 'You are authorised.';
declare const NOT_AUTHORISED_MSG = 'You do not have sufficient permission.';
declare enum Resources {
  ACCOUNTS = 'account',
  TRANSACTIONS = 'transaction',
  CUSTOMER = 'customer',
  PAC = 'PAC',
}
declare enum Actions {
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  INITIATE_PAYMENT = 'initiatePayment',
  INITIATE_TRANSFER = 'initiateTransfer',
  INITIATE_PAYMENT_RETURN = 'initiatePaymentReturn',
  VIEW_BENEFICIARIES = 'viewBeneficiaries',
  OVER_RIDE_CREDIT_INTEREST = 'overrideCreditInterest',
  VIEW_DEFAULT_PERMISSIONS = 'viewDefaultPermissions',
  VIEW = 'view',
  OPEN_ACCOUNT = 'openAccount',
  CLOSE_ACCOUNT = 'closeAccount',
  BLOCK_ACCOUNT = 'blockAccount',
  UNBLOCK_ACCOUNT = 'unblockAccount',
  BLOCK_CUSTOMER = 'blockCustomer',
  UNBLOCK_CUSTOMER = 'unblockCustomer',
  AUTHORISE_PAYMENT = 'authorisePayment',
  AUTHORISE_TRANSFER = 'authoriseTransfer',
  CREATE_USER = 'createUser',
  AUTHORISE_USER = 'authoriseUser',
  MANAGE_ACCOUNT_NAME = 'manageAccountName',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
}

type AuthorisationOutcome = {
  authorised: boolean;
  message: string;
};

declare const useAuthoriser: (
  resource: Resources,
  action: Actions
) => AuthorisationOutcome;

declare const isUserAuthorised: (
  resource: Resources,
  action: Actions
) => AuthorisationOutcome;

export {
  AUTHORISED_MSG,
  Actions,
  AuthorisationOutcome,
  NOT_AUTHORISED_MSG,
  Resources, isUserAuthorised, useAuthoriser
};

