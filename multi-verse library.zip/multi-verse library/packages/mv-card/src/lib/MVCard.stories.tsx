import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import MVCard, { MVCardProps } from '../MVCard';
import { GridItem } from '@westpac/ui';

// default export with component metadata
export default {
  title: 'Components/MVCard',
  tags: ['autodocs'],
  component: MVCard,
} as Meta<typeof MVCard>;

// template for creating stories
const Template: StoryFn<typeof MVCard> = args => <MVCard {...args} />;

// sample data for the stories
const exampleTitle = 'Card Title';
const exampleSubtitle = 'Card Subtitle';
const exampleContent = (
  <GridItem span={12}>
    <p>This is the content of the card.</p>
  </GridItem>
);

// default settings
export const Default = Template.bind({});
Default.args = {
  title: exampleTitle,
  subtitle: exampleSubtitle,
  children: exampleContent,
  template: 'wide',
  bottomDivider: true,
} as MVCardProps;

// with only title
export const OnlyTitle = Template.bind({});
OnlyTitle.args = {
  title: exampleTitle,
  children: exampleContent,
  template: 'wide',
  bottomDivider: true,
} as MVCardProps;

// with only subtitle
export const OnlySubtitle = Template.bind({});
OnlySubtitle.args = {
  subtitle: exampleSubtitle,
  children: exampleContent,
  template: 'wide',
  bottomDivider: true,
} as MVCardProps;
