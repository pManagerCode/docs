import { Popover } from '@westpac/ui';
import React from 'react';

export type AccountDetailsItem = {
  value: string;
  /**  Apply a style class to override the default label style
   * e.g: className: 'm-0 font-semibold text-muted'
   * */
  className?: string;
} & (
  | {
      variant: 'accessory-icon';
      /** left accessory icon */
      accessory: React.ReactNode;
      hint: string;
      /** label is required if the accessory is set.*/
      label: string;
    }
  | {
      variant: 'text';
      label?: string;
    }
);

export type MVAccountFormatterProps = {
  details: string[] | AccountDetailsItem[];
};

type LayoutType = 'list' | 'styled-list' | 'two-column-list';

function MVAccountFormatter(props: MVAccountFormatterProps) {
  const getLayout = (details: string[] | AccountDetailsItem[]): LayoutType => {
    // array of strings
    if (details.every(detail => typeof detail === 'string')) return 'list';
    // array of key-value pairs
    else if (details.every(detail => detail?.label !== undefined))
      return 'two-column-list';
    else return 'styled-list';
  };

  const createLayout = (details: string[] | AccountDetailsItem[]) => {
    const layout = getLayout(details);
    switch (layout) {
      case 'list': {
        return details.map((detail, index) => {
          if (typeof detail === 'string') {
            return (
              <p
                className={`m-0 overflow-hidden break-words typography-body-10 ${index === 0 ? 'font-semibold text-hero' : 'font-normal'}`}
                key={detail + index}
              >
                {detail}
              </p>
            );
          }
          return null;
        });
      }
      case 'styled-list': {
        return details.map(detail => {
          const { value, className } = detail as AccountDetailsItem;
          return (
            <p className={className} key={value}>
              {value}
            </p>
          );
        });
      }
      case 'two-column-list': {
        const labels = details.map(detail => {
          const accountDetails = detail as AccountDetailsItem;
          return {
            label: accountDetails.label,
            ...(accountDetails.variant === 'accessory-icon' && {
              hint: accountDetails.hint,
              accessory: accountDetails.accessory ?? null,
            }),
          };
        });

        return (
          <div className="flex flex-row space-x-4">
            <div className="flex shrink-0 flex-col">
              {labels.map(item => {
                return (
                  <div className="relative" key={item.label}>
                    {item.accessory ? (
                      <Popover
                        className="w-fit h-fit top-[-9px] left-[-36px] absolute"
                        content={item.hint || ''}
                        placement="bottom"
                        icon={() => <>{item.accessory}</>}
                      />
                    ) : null}
                    <p
                      className={`flex break-words m-0  overflow-hidden typography-body-10 font-semibold text-text`}
                    >
                      {item.label}
                    </p>
                  </div>
                );
              })}
            </div>
            <div className="flex flex-col overflow-hidden">
              {details.map(detail => {
                const { value, className } = detail as AccountDetailsItem;
                return (
                  <p key={value} className={className}>
                    {value}
                  </p>
                );
              })}
            </div>
          </div>
        );
      }
    }
  };

  return createLayout(props.details);
}

export default MVAccountFormatter;
