import * as React from 'react';

export type MVRefreshProps = {
  /**
   * Function to call when the refresh action is triggered
   */
  onRefresh: () => void;

  /**
   * Boolean to disable the refresh button
   */
  disabled?: boolean;
};

export type MVRefreshHandle = {
  /**
   * Function to refresh the current date and time
   */
  refreshDateTime: () => void;
};

export const MVRefresh: React.ForwardRefExoticComponent<
  React.PropsWithoutRef<MVRefreshProps> & React.RefAttributes<MVRefreshHandle>
>;
