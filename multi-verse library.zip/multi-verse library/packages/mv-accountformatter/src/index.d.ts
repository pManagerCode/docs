import * as React from 'react';

export type AccountDetailsItem = {
  value: string;
  /**  Apply a style class to override the default label style
   * e.g: className: 'm-0 font-semibold text-muted'
   * */
  className?: string;
} & (
  | {
      variant: 'accessory-icon';
      /** left accessory icon */
      accessory: React.ReactNode;
      hint: string;
      /** label is required if the accessory is set.*/
      label: string;
    }
  | {
      variant: 'text';
      label?: string;
    }
);

export type MVAccountFormatterProps = {
  details: string[] | AccountDetailsItem[];
};

export const MVAccountFormatter: React.FC<MVAccountFormatterProps>;
