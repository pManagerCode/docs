import { Resources, Actions } from './constants';

export type AuthorisationOutcome = {
  authorised: boolean;
  message: string;
};

export type RoleBaseAuthorisationModel = {
  roles: string[];
};

export type RoleBaseJwtModel = {
  role: string | string[];
};

export type AuthorisationModel<T> = {
  resource: Resources;
  action: Actions;
  model: T;
};

export type Rule<T> = (facts: AuthorisationModel<T>) => boolean;
