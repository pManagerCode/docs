import React, { useState, useRef, useEffect, forwardRef } from 'react';
import { Grid, GridItem, InputGroup } from '@westpac/ui';
import { SearchIcon } from '@westpac/ui/icon';
import { mergeRefs } from '../../mv-utils/src';

export type ListOption = {
  name: string;
  id: string;
  entityName?: string;
  accountType?: string;
  payeeType?: string;
  domestic?: {
    accountName?: string;
  };
};

export interface MVAutoCompleteProps {
  defaultInputValue: string;
  listOptions: ListOption[];
  setSearchItem: (value: ListOption) => void;
  onBlur: () => void;
  isError: boolean;
  isAdditionalError?: boolean;
  autoFocus?: boolean;
  errorMessage: string;
  header: string;
  helpText: string;
  renderOption?: (option: ListOption) => JSX.Element;
  renderValue?: (option: ListOption) => string;
  optionsMaxHeight?: number;
  isIconVisible?: boolean;
  maxVisibleOptions?: number;
  defaultInputOption?: ListOption;
  placeholder?: string;
  renderOptionOnHover?: (option: ListOption) => JSX.Element;
}

const MVAutoComplete = forwardRef<HTMLInputElement, MVAutoCompleteProps>(
  (
    {
      defaultInputValue,
      listOptions,
      setSearchItem,
      isError,
      errorMessage,
      header,
      helpText,
      autoFocus,
      onBlur,
      renderOption,
      renderValue,
      optionsMaxHeight,
      isIconVisible = true,
      maxVisibleOptions = 20,
      defaultInputOption,
      placeholder = '',
      renderOptionOnHover,
      isAdditionalError = false,
    },
    ref
  ) => {
    const [inputValue, setInputValue] = useState(defaultInputValue);
    const [selectedIndex, setSelectedIndex] = useState(-1);
    const [showOptions, setShowOptions] = useState(false);
    const [showError, setShowError] = useState(isError);
    const [options, setOptions] = useState(listOptions);
    const [selectedOption, setSelectedOption] = useState<ListOption | null>(
      null
    );

    const [ignoreBlur, setIgnoreBlur] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);
    const styledListItemRef = useRef<HTMLDivElement>(null);
    const toggleOptions = () => {
      setShowOptions(!showOptions);
    };

    const combinedRefs = mergeRefs([inputRef, ref]);

    const optionValues = listOptions.map(option =>
      renderValue ? renderValue(option) : `${option.name} - ${option.id}`
    );

    const handleOnMouseClick = (e: MouseEvent) => {
      if (
        styledListItemRef.current &&
        e.target instanceof Node && // Ensure e.target is a Node
        !styledListItemRef.current.contains(e.target)
      ) {
        setShowOptions(false);
      }
    };

    useEffect(() => {
      if (inputRef.current && autoFocus) {
        inputRef.current.focus();
      }
      if (inputValue === '' && !showOptions) {
        setSelectedOption(null);
        setInputValue('');
        setSelectedIndex(-1);
        setShowError(true);
      }
    }, [showOptions]);

    useEffect(() => {
      setOptions(listOptions);
      if (defaultInputOption) {
        const filteredOptions = listOptions.filter(option => {
          const optionNameId = `${option?.name?.toLowerCase()} - ${option?.id?.toLowerCase()} ${option?.entityName?.toLowerCase()} ${option?.accountType?.toLowerCase()} ${option?.domestic?.accountName?.toLowerCase()}`;
          return optionNameId.includes(defaultInputOption?.id?.toLowerCase());
        });

        setIgnoreBlur(true);
        setInputValue(
          renderValue
            ? renderValue(defaultInputOption)
            : `${defaultInputOption.name} - ${defaultInputOption.id}`
        );
        setSelectedOption(defaultInputOption);
        setSearchItem(defaultInputOption);
        setShowOptions(false);
        setSelectedIndex(-1);
        setOptions(filteredOptions);
      }
    }, [listOptions]);

    useEffect(() => {
      if (!inputValue || optionValues.includes(inputValue)) {
        setOptions(listOptions);
        return;
      }
      const filteredOptions = listOptions.filter(option => {
        const optionNameId = `${option?.name?.toLowerCase()} - ${option?.id?.toLowerCase()} ${option?.entityName?.toLowerCase()} ${option?.accountType?.toLowerCase()} ${option?.domestic?.accountName?.toLowerCase()}`;
        return optionNameId.includes(inputValue?.toLowerCase());
      });
      setOptions(filteredOptions);
    }, [inputValue]);

    useEffect(() => {
      if (!isError) {
        setShowError(false);
      } else if (isError) {
        setShowError(true);
      }
    }, [isError]);

    useEffect(() => {
      document.addEventListener('mousedown', handleOnMouseClick);

      return () => {
        document.removeEventListener('mousedown', handleOnMouseClick);
      };
    }, []);

    const handleOptionClick = (option: ListOption) => {
      setShowError(false);
      setIgnoreBlur(true);
      setInputValue(
        renderValue ? renderValue(option) : `${option.name} - ${option.id}`
      );
      setSelectedOption(option);
      setSearchItem(option);
      setShowOptions(false);
      setSelectedIndex(-1);
    };

    const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      setIgnoreBlur(true);
      const { value } = event.target;
      setInputValue(value);

      // clear setting

      setSelectedOption(null);
      setSearchItem(null);
      setSelectedIndex(-1);
      setShowError(true);

      setShowOptions(false);
      setOptions(listOptions);

      // filter from the option list

      const filteredOptions = listOptions.filter(option => {
        const optionNameId = `${option.name.toLowerCase()} - ${option.id.toLowerCase()} ${option?.entityName?.toLowerCase()} ${option?.accountType?.toLowerCase()} ${option?.domestic?.accountName?.toLowerCase()}`;
        return optionNameId.includes(value?.toLowerCase());
      });

      if (filteredOptions.length) {
        setOptions(filteredOptions);
        setShowOptions(true);
      }
    };

    const [shouldFocusOnOption, setShouldFocusOnOption] = useState(false);

    useEffect(() => {
      if (showOptions && shouldFocusOnOption) {
        if (selectedIndex >= 0 && selectedIndex < options.length) {
          const optionElement = document.getElementById(
            `option-${selectedIndex}`
          );
          if (optionElement) {
            optionElement.scrollIntoView();
          }
        }
      } else if (inputRef.current && autoFocus) {
        inputRef.current.focus();
      }
    }, [showOptions, selectedIndex, shouldFocusOnOption]);

    const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
      e.target.setSelectionRange(e.target.value.length, e.target.value.length);
    };

    const handleBlur = () => {
      if (ignoreBlur) {
        setIgnoreBlur(false);
        return;
      }
      setShowOptions(false);
      onBlur();
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Backspace') {
        if (inputValue !== '') {
          e.preventDefault();
          const newValue = inputValue.slice(0, -1);
          setInputValue(newValue);
          const filteredOptions = listOptions.filter(
            option =>
              option.name.toLowerCase().startsWith(inputValue.toLowerCase()) ||
              option?.accountType
                ?.toLowerCase()
                .startsWith(inputValue.toLowerCase()) ||
              option?.payeeType
                ?.toLowerCase()
                .startsWith(inputValue.toLowerCase()) ||
              option.entityName
                ?.toLowerCase()
                .startsWith(inputValue.toLowerCase()) ||
              option.id.toLowerCase().startsWith(inputValue.toLowerCase())
          );
          setOptions(filteredOptions);
          setShowOptions(true);
          if (filteredOptions.length > 0) {
            setSelectedIndex(0);
            setShouldFocusOnOption(true);
          } else {
            setInputValue('');
            setSearchItem(null);
          }
        }
      }

      if (e.key === 'ArrowDown') {
        if (inputValue === '' && !showOptions) {
          setShowOptions(true);
          setSelectedIndex(0);
          setShouldFocusOnOption(true);
        } else if (inputValue !== '' && !showOptions) {
          setShowOptions(true);
          setSelectedIndex(0);
          setShouldFocusOnOption(true);
        } else if (showOptions && selectedIndex < options.length - 1) {
          setSelectedIndex(prevIndex => prevIndex + 1);
          setShouldFocusOnOption(true);
        }
      } else if (e.key === 'ArrowUp') {
        if (selectedIndex === -1 || selectedIndex === 0) {
          if (!showOptions) {
            setShowOptions(true);
            setShouldFocusOnOption(false);
          }
          setSelectedIndex(options.length - 1);
        } else if (selectedIndex > 0) {
          setSelectedIndex(selectedIndex - 1);
          setShouldFocusOnOption(true);
        }
      } else if (e.key === 'Enter' && selectedIndex !== -1) {
        e.preventDefault();
        const value = `${options[selectedIndex].name} - ${options[selectedIndex].id}`;
        setInputValue(value);
        setSearchItem(options[selectedIndex]);
        setSelectedIndex(-1);
        setShowOptions(false);
        setShowError(false);
        setShouldFocusOnOption(false);
      } else if (e.key === 'Escape') {
        setShowOptions(false);
        setSelectedIndex(-1);
        setShouldFocusOnOption(false);
      } else if (e.key === 'Home') {
        if (inputRef.current) {
          inputRef.current.setSelectionRange(0, 0);
        }
      } else if (e.key === 'End') {
        if (inputRef.current) {
          inputRef.current.setSelectionRange(
            inputValue.length,
            inputValue.length
          );
        }
      } else if (e.key === 'Tab') {
        setShowOptions(false);
        setShouldFocusOnOption(false);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        setIgnoreBlur(false);
        handleBlur();
      }
    };

    return (
      <div className="relative pb-2.5" ref={styledListItemRef}>
        <div className="relative group">
          <span className="flex w-full">
            <InputGroup
              errorMessage={
                (showError || isAdditionalError) && errorMessage
                  ? errorMessage
                  : ''
              }
              size="small"
              label={header}
              hint={helpText}
              className="w-full mb-0"
              before={
                isIconVisible
                  ? {
                      icon: props => <SearchIcon {...props} size="small" />,
                    }
                  : ''
              }
            >
              <input
                className={`flex-1 h-5 border text-sm text-[#181b25] ${showError ? 'border-[#C40000] input-error' : 'border-[#b6b8c1]'} pl-5 rounded outline-none`}
                id="combobox-input"
                role="combobox"
                aria-autocomplete="list"
                autoComplete="off"
                aria-controls="combobox-listbox"
                aria-activedescendant={
                  selectedIndex === -1 ? '' : `option-${selectedIndex}`
                }
                aria-expanded={showOptions}
                aria-labelledby="combobox-label"
                ref={combinedRefs}
                type="text"
                value={inputValue}
                onChange={handleInputChange}
                onKeyDown={handleKeyPress}
                onFocus={handleFocus}
                onClick={toggleOptions}
                onBlur={handleBlur}
                placeholder={placeholder}
              />
            </InputGroup>
          </span>
          {showOptions && (
            <ul
              className="absolute w-full overflow-y-auto overflow-x-hidden border border-t-0 border-border rounded-b box-borde bg-white z-10 list-none pl-0 mt-0"
              id="combobox-listbox"
              role="listbox"
              aria-label=""
              style={{ maxHeight: optionsMaxHeight, overflowY: 'auto' }}
            >
              {options.slice(0, maxVisibleOptions).map((option, index) => (
                <li
                  className="px-2 py-1 cursor-pointer hover:bg-background hover:text-[#181b25]"
                  id={`option-${index}`}
                  key={option.id}
                  tabIndex={0}
                  role="option"
                  aria-selected={index === selectedIndex}
                  onClick={() => handleOptionClick(option)}
                  onMouseDown={() => setIgnoreBlur(true)}
                  onKeyDown={event => {
                    if (event.key === 'Enter' || event.key === ' ') {
                      event.preventDefault();
                      handleOptionClick(option);
                    }
                  }}
                >
                  {renderOption ? (
                    renderOption(option)
                  ) : (
                    <Grid className="gap-0">
                      <GridItem span={6}>{option.name}</GridItem>
                      <GridItem className="text-right" span={6}>
                        {option.id}
                      </GridItem>
                    </Grid>
                  )}
                </li>
              ))}

              <div className="p-0 w-full mt-2">
                {options.length > 0 && <hr style={{ width: '100%' }} />}
                <div className="pl-3 pr-1.5 pb-1 mt-1">
                  Showing{' '}
                  {maxVisibleOptions < options.length
                    ? maxVisibleOptions
                    : options.length}{' '}
                  of {options.length}{' '}
                  {options.length === 1 ? 'result' : 'results'}
                </div>
              </div>
            </ul>
          )}
          {!showOptions &&
            selectedOption &&
            !renderOptionOnHover &&
            renderOption && (
              <div
                className="z-10 pointer-events-none absolute p-1.5 mt-2 rounded bg-white min-w-[275px] max-w-full opacity-0 group-hover:opacity-100"
                style={{ boxShadow: '0px 0px 8px rgba(68, 76, 95, 0.2)' }}
              >
                {renderOption(selectedOption)}
                <div
                  className="absolute w-2 h-2 bg-white -top-1 left-1/2 transform -translate-x-1/2 rotate-45"
                  style={{ boxShadow: '-4px -4px 8px rgba(68, 76, 95, 0.2)' }}
                />
              </div>
            )}
          {!showOptions && selectedOption && renderOptionOnHover && (
            <div
              className="z-10 pointer-events-none absolute p-2.5 mt-2 rounded bg-white min-w-[275px] max-w-full opacity-0 group-hover:opacity-100"
              style={{ boxShadow: '0px 0px 8px rgba(68, 76, 95, 0.2)' }}
            >
              {renderOptionOnHover(selectedOption)}
              <div
                className="absolute w-2 h-2 bg-white -top-1 left-1/2 transform -translate-x-1/2 rotate-45"
                style={{ boxShadow: '-4px -4px 8px rgba(68, 76, 95, 0.2)' }}
              />
            </div>
          )}
        </div>
      </div>
    );
  }
);

MVAutoComplete.displayName = 'MVAutoComplete';

export default MVAutoComplete;
