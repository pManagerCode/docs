import React from 'react';
import { Badge, Grid, GridItem, Well } from '@westpac/ui';

type MVAccountSummaryItem = {
  title: string;
  content: React.ReactNode | string;
  status?: string;
  statusColor?: 'success' | 'hero' | 'warning' | 'danger';
  maxWidth?: number;
  minWidth?: number;
};

export type MVAccountSummaryProps = {
  header?: React.ReactNode;
  items: MVAccountSummaryItem[];
  error?: React.ReactNode;
};

export default function MVAccountSummary(props: MVAccountSummaryProps) {
  const { header, items, error } = props;

  return (
    <Well className="!p-2.5 w-full mt-2.5 mb-2.5 bg-light border-light">
      {header}
      {error}
      <Grid tag="ol" className="mt-2 flex flex-wrap !gap-1.5">
        {items.map((item, i) => {
          const classes = [];
          const styles: React.CSSProperties = {};
          if (i !== items.length - 1) {
            classes.push('pr-1.5 border-border border-r-[1px]');
          }

          if (!isNaN(item.minWidth)) {
            styles.minWidth = `${item.minWidth}rem`;
          }
          if (!isNaN(item.maxWidth)) {
            styles.maxWidth = `${item.maxWidth}rem`;
          }

          return (
            <GridItem
              key={item.title}
              tag="li"
              className={classes.join(' ')}
              style={styles}
            >
              <p className="typography-body-9 text-muted font-bold">
                {item.title}
              </p>
              <p className="typography-body-9 font-normal mt-0.5 truncate text-ellipsis">
                {item.content}
              </p>
              {item.status && (
                <Badge
                  color={item.statusColor ?? 'success'}
                  soft
                  className="mt-1"
                >
                  {item.status}
                </Badge>
              )}
            </GridItem>
          );
        })}
      </Grid>
    </Well>
  );
}
