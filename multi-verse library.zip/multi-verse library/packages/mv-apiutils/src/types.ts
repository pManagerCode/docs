import { Response } from 'express';
import BunyanLogger from 'bunyan';

export type APIClientError = {
  type: string;
  error: {
    status: number;
    statusText: string;
  };
};

export type Logger = BunyanLogger | Console;

export type HandleControllerErrorParams = {
  error: APIClientError;
  controllerName: string;
  res: Response;
  logger: Logger;
};
