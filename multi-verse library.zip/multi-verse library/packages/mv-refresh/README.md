# @mesh-tenant-multiverse-ui-common/mv-refresh

## Purpose

The `MVRefresh` component provides a refresh button that displays the last refreshed time and allows users to trigger a refresh action. It is built with React and styled using Tailwind CSS.

## Usage

To use the `MVRefresh` component, follow these steps:

1. Import the component in your file:

   ```jsx
   import MVRefresh from '@mesh-tenant-multiverse-ui-common/mv-refresh';
   ```

2. Add the `MVRefresh` component to your JSX code and provide the necessary props:

   ```jsx
   import React, { useRef } from 'react';
   import MVRefresh from '@mesh-tenant-multiverse-ui-common/mv-refresh';

   const MyComponent = () => {
     const refreshRef = useRef();

     const handleRefresh = () => {
       console.log('Refreshed!');
     };

     return (
       <MVRefresh ref={refreshRef} onRefresh={handleRefresh} disabled={false} />
     );
   };

   export default MyComponent;
   ```

## Props

The `MVRefresh` component accepts the following props:

- `onRefresh` (required): Function to call when the refresh action is triggered.
- `disabled` (optional): Boolean to disable the refresh button.

## Example

Here's an example of how to use the `MVRefresh` component:

```jsx
import React, { useRef } from 'react';
import MVRefresh from '@mesh-tenant-multiverse-ui-common/mv-refresh';

const MyComponent = () => {
  const refreshRef = useRef();

  const handleRefresh = () => {
    console.log('Refreshed!');
  };

  return (
    <MVRefresh ref={refreshRef} onRefresh={handleRefresh} disabled={false} />
  );
};

export default MyComponent;
```
