import { jwtDecode, InvalidTokenError } from '../src/jwt';
import { RoleBaseJwtModel } from '../src/types';

describe('jwt-decode', () => {
  test('should return header information', () => {
    const token =
      'eyJhbGciOiJSUzI1NiIsImtpZCI6ImtKbWhNdVRVc3VGLXo4bURySUduSld4QnI0NF9SUzI1NiIsInBpLmF0bSI6InMxOWMifQ.eyJzY29wZSI6WyJnYWxheHkiLCJvcGVuaWQiLCJwcm9maWxlIl0sImNsaWVudF9pZCI6IndkcHVpLWNjbXAtYmV0YSIsImlhdCI6MTcxMzE0MTE0OCwianRpIjoiRE5sNDR1UWo2YktxelhKSnhPMUVjQ1N2R3ZUS3c4QjciLCJ1c2VySWRTY2hlbWUiOiJDb3Jwb3JhdGVVc2VySWQiLCJhdWQiOiJndy1jdXN0b21lci5kZXYxLmFwaS53ZXN0cGFjLmNvbS5hdSIsInN1YiI6IndpbGwuc21pdGhAd2JjLmNvbSIsInJvbGUiOiJhZ2VudCIsInNlc3Npb25JbmRleCI6IjQ0NWExM2QyLWI5MTQtNDA5Mi1hZjg0LWRlMzk3YWY2MGEzYSIsInRyYWNrZXJJZCI6IjU3MmE2Y2E5LTkwMjgtNDQxOC04MDJmLWM1ZmQwMTBmMDUxZCIsImlzcyI6Imh0dHBzOi8vaW50ZXJuYWwuYTAwY2NjLmFwczIuZGV2MDQuYXdzZWx6Lndlc3RwYWMuY29tLmF1L2lkZW50aXR5IiwidXNlcklkIjoiNDYzNjIxMjAwOTkiLCJleHAiOjE3MTMxNDE0NDh9.OFrPe9fRQsvp4z0RWXpXLVESkvRSMUWtXmdam1jJ3QzfIV0VQ_4Bf-_1C7n47b0ACRWtM4JEMZcU_vUeDE3ZM4I64vKAPWk5oAsG6pzhXln0Yq5GKEpHWbSePmnRdimKcVuhQXCBvSC_c_kIMYh2rTwxs0DSsIHXJmrvY9jxKgYjIwfLzM2yiRe8TfiifL0vNxMYH8ue8wnnJZrpb3_YbxO9lpkrf8ZZfwdyWPizY_A4w1RWkikk1MYiKobxhZk5TehU5ZyskRRIsquAgUVClL_l0dQw4NMkC55iybMg-FE1CXreSxntmgBv9gyyFVhrihlzeNRuR1f3X_xDTaM6RZvfKx7C1wYjS3Ba5Tf2VL6KGtr0qFyJyzvZ7pWAVJev5npxulu1wRiNS4ExoCZiMjIwJLrsV6Zz8Ilj9RfTRPJZ7uHa9CzsV5VU4TYTlriqSqe_VguysnlGSKlfg7Bopgg4qXTGH9jRtAT8RIlHltofl5Hrz897vlkNudvBe9VKDeOakvd1fZIwwSB_Z1m1ARym11vRbH-QqdU718iSZkUa0wZwIBAnpmKEC-b7DqZCkRmUgpRI7y_X-qfuEhHlyD4CbyI80kEEAYVR85kDF9076ulV0RX5Qy2JQZAEUEs4e7Rk1wDb-CCAosPeATgKfMzmbARTTaaLAZfL-KMqnr8';
    const decoded = jwtDecode(token, { header: true });
    expect(decoded.kid).toEqual('kJmhMuTUsuF-z8mDrIGnJWxBr44_RS256');
    expect(decoded.alg).toEqual('RS256');
  });

  test('should return role', () => {
    const token =
      'eyJhbGciOiJSUzI1NiIsImtpZCI6ImtKbWhNdVRVc3VGLXo4bURySUduSld4QnI0NF9SUzI1NiIsInBpLmF0bSI6InMxOWMifQ.eyJzY29wZSI6WyJnYWxheHkiLCJvcGVuaWQiLCJwcm9maWxlIl0sImNsaWVudF9pZCI6IndkcHVpLWNjbXAtYmV0YSIsImlhdCI6MTcxMzE0MTE0OCwianRpIjoiRE5sNDR1UWo2YktxelhKSnhPMUVjQ1N2R3ZUS3c4QjciLCJ1c2VySWRTY2hlbWUiOiJDb3Jwb3JhdGVVc2VySWQiLCJhdWQiOiJndy1jdXN0b21lci5kZXYxLmFwaS53ZXN0cGFjLmNvbS5hdSIsInN1YiI6IndpbGwuc21pdGhAd2JjLmNvbSIsInJvbGUiOiJhZ2VudCIsInNlc3Npb25JbmRleCI6IjQ0NWExM2QyLWI5MTQtNDA5Mi1hZjg0LWRlMzk3YWY2MGEzYSIsInRyYWNrZXJJZCI6IjU3MmE2Y2E5LTkwMjgtNDQxOC04MDJmLWM1ZmQwMTBmMDUxZCIsImlzcyI6Imh0dHBzOi8vaW50ZXJuYWwuYTAwY2NjLmFwczIuZGV2MDQuYXdzZWx6Lndlc3RwYWMuY29tLmF1L2lkZW50aXR5IiwidXNlcklkIjoiNDYzNjIxMjAwOTkiLCJleHAiOjE3MTMxNDE0NDh9.OFrPe9fRQsvp4z0RWXpXLVESkvRSMUWtXmdam1jJ3QzfIV0VQ_4Bf-_1C7n47b0ACRWtM4JEMZcU_vUeDE3ZM4I64vKAPWk5oAsG6pzhXln0Yq5GKEpHWbSePmnRdimKcVuhQXCBvSC_c_kIMYh2rTwxs0DSsIHXJmrvY9jxKgYjIwfLzM2yiRe8TfiifL0vNxMYH8ue8wnnJZrpb3_YbxO9lpkrf8ZZfwdyWPizY_A4w1RWkikk1MYiKobxhZk5TehU5ZyskRRIsquAgUVClL_l0dQw4NMkC55iybMg-FE1CXreSxntmgBv9gyyFVhrihlzeNRuR1f3X_xDTaM6RZvfKx7C1wYjS3Ba5Tf2VL6KGtr0qFyJyzvZ7pWAVJev5npxulu1wRiNS4ExoCZiMjIwJLrsV6Zz8Ilj9RfTRPJZ7uHa9CzsV5VU4TYTlriqSqe_VguysnlGSKlfg7Bopgg4qXTGH9jRtAT8RIlHltofl5Hrz897vlkNudvBe9VKDeOakvd1fZIwwSB_Z1m1ARym11vRbH-QqdU718iSZkUa0wZwIBAnpmKEC-b7DqZCkRmUgpRI7y_X-qfuEhHlyD4CbyI80kEEAYVR85kDF9076ulV0RX5Qy2JQZAEUEs4e7Rk1wDb-CCAosPeATgKfMzmbARTTaaLAZfL-KMqnr8';
    const decoded = jwtDecode<RoleBaseJwtModel>(token);
    expect(decoded.role).toEqual('agent');
  });

  it('should throw InvalidTokenError on nonstring', () => {
    const badToken = null;
    expect(() => {
      jwtDecode(badToken as unknown as string);
    }).toThrow(InvalidTokenError);
  });

  it('should throw InvalidTokenError on string that is not a token', () => {
    const badToken = 'xxxxxxxxx';
    expect(() => {
      jwtDecode(badToken);
    }).toThrow(InvalidTokenError);
  });

  it('should throw InvalidTokenErrors when part #1 is not valid base64', () => {
    const badToken = 'TOKEN';
    expect(() => {
      jwtDecode(badToken, { header: true });
    }).toThrow(/Invalid token specified:/);
  });
});
