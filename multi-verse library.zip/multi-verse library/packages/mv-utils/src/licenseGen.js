/*
  copy paste this file to chrome -> devtools -> console to run it
  cannot run from via node CLI since window.crypto is used
*/

function bufferToBase64(buf) {
  let binary = '';
  let bytes = new Uint8Array(buf);
  let len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

const generateKeys = async () => {
  console.log('generating keys ...');
  let keyPair = await window.crypto.subtle.generateKey(
    {
      name: 'RSA-OAEP',
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: 'SHA-256',
    },
    true,
    ['encrypt', 'decrypt']
  );

  let exportedPublicKey = await window.crypto.subtle.exportKey(
    'spki',
    keyPair.publicKey
  );

  let exportedPrivateKey = await window.crypto.subtle.exportKey(
    'pkcs8',
    keyPair.privateKey
  );

  let publicKeyBase64 = bufferToBase64(exportedPublicKey);
  let privateKeyBase64 = bufferToBase64(exportedPrivateKey);

  // log keys for later use, keep note of the privateKeyBase64 for app-config galaxyTable.key
  console.log('key:', encodeURIComponent(privateKeyBase64));

  return {
    publicKeyBase64: publicKeyBase64,
    privateKeyBase64: privateKeyBase64,
  };
};

const { publicKeyBase64 } = await generateKeys();

function splitIntoChunks(str, chunkSize) {
  let chunks = [];
  for (let i = 0; i < str.length; i += chunkSize) {
    chunks.push(str.substring(i, i + chunkSize));
  }
  return chunks;
}

const encryptDataChunksToString = async (secret, publicKey) => {
  console.log('encrypting secret ...');
  const chunkSize = 190;
  const chunks = splitIntoChunks(secret, chunkSize);

  const encryptedChunkBase64s = [];

  for (let chunk of chunks) {
    const encryptedChunk = await window.crypto.subtle.encrypt(
      { name: 'RSA-OAEP' },
      publicKey,
      new TextEncoder().encode(chunk)
    );

    const encryptedChunkBase64 = bufferToBase64(encryptedChunk);
    encryptedChunkBase64s.push(encryptedChunkBase64);
  }
  const encryptedChunkString = encryptedChunkBase64s.join('|');
  console.log('lic:', encodeURIComponent(encryptedChunkString));
  console.log('Done!');
  return encryptedChunkString;
};

function base64ToArrayBuffer(base64) {
  const binary_string = window.atob(base64);
  const len = binary_string.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary_string.charCodeAt(i);
  }

  return bytes.buffer;
}

const publicKeyArrayBuffer = base64ToArrayBuffer(publicKeyBase64);

const publicKey = await window.crypto.subtle.importKey(
  'spki',
  publicKeyArrayBuffer,
  {
    name: 'RSA-OAEP',
    hash: 'SHA-256',
  },
  true,
  ['encrypt']
);

// Update below before running this file to generate the keys and encrypted license string
let secret = {
  spaName: 'galaxy', // set this to your SPA componentName
  license: `Get from agGrid via Westpac ETAM`,
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
let encryptedChunkString = await encryptDataChunksToString(
  JSON.stringify(secret),
  publicKey
);

/* Once you run this, copy the following into app-config
  "galaxyTable": {
    "key": privateKeyBase64
    "lic": encryptedChunkString
  }
*/
