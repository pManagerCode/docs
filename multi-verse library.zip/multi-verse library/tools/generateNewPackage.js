/* eslint-disable @typescript-eslint/no-var-requires */
const fs = require('fs');
const { createNewPackageFolder } = require('./createNewPackageFolder');

const newPackageName = process.argv[2];
const componentName = process.argv[3];

if (!newPackageName) {
  console.error('Please provide both a package name and a component name.');
  process.exit(1);
}

const newPackagePath = `./packages/${newPackageName}`;

// Step 1: Create new package folder
if (!fs.existsSync(newPackagePath)) {
  fs.mkdirSync(newPackagePath);
}

// Step 2: Create initial files in the new package folder
createNewPackageFolder(newPackageName, componentName);

// Step 3: Update library package.json
const libraryPackageJsonPath = './packages/library/package.json';

const libraryPackageJson = JSON.parse(
  fs.readFileSync(libraryPackageJsonPath, 'utf8')
);
libraryPackageJson.devDependencies[
  `@mesh-tenant-multiverse-ui-common/${newPackageName}`
] = `file:../${newPackageName}`;
fs.writeFileSync(
  libraryPackageJsonPath,
  JSON.stringify(libraryPackageJson, null, 2)
);

// Step 4: Update library index.jsx and index.d.ts
const libraryIndexJsxPath = './packages/library/src/index.ts';

fs.appendFileSync(
  libraryIndexJsxPath,
  `export * from '@mesh-tenant-multiverse-ui-common/${newPackageName}';\n`
);

console.log(`Package ${newPackageName} created successfully.`);
// Prompt the user about the next steps
console.log(
  `Next steps: We will remove the node_modules and dist directory, rebuild the packages. Please wait...`
);
