import glob, shutil, os

# this method copies over README.md files from every component
# into the docs folder before the site is built 
def on_pre_build(*args, **kwargs):
    shutil.rmtree('docs/packages/', ignore_errors=True)
    shutil.copy('README.md', 'docs/index.md')
    for files in ["packages/**/README.md"]:
        for f in glob.glob(files):
            split=os.path.split(f)
            dest_dir=f'docs/{split[0]}/'
            os.makedirs(dest_dir)            
            shutil.copy(f, dest_dir)

# this method resolves the inifinite build loop that occurs in local development
# livereload will now only happen when the following files are changed:
# 'mkdocs.yml', 'docs/stylesheets', and the READMEs in 'addons' and 'core'
def on_serve(*args, **kwargs):
    args[0].unwatch("docs/")
    args[0].watch("docs/stylesheets")
    for files in ["packages/**/README.md", "README.md"]:
        for f in glob.glob(files):
            args[0].watch(f)
