import { debounce } from '../src/debounce';

jest.useFakeTimers();

describe('debounce', () => {
  it('should call the callback immediately', () => {
    const callback = jest.fn();
    const finalCallback = jest.fn();
    const debouncedFunction = debounce(callback, 1000, finalCallback);

    debouncedFunction();

    expect(callback).toHaveBeenCalledTimes(1);
  });

  it('should call the finalCallback after the specified time', () => {
    const callback = jest.fn();
    const finalCallback = jest.fn();
    const debouncedFunction = debounce(callback, 1000, finalCallback);

    debouncedFunction();

    jest.advanceTimersByTime(1000);

    expect(finalCallback).toHaveBeenCalledTimes(1);
  });

  it('should not call the callback again if called multiple times within the specified time', () => {
    const callback = jest.fn();
    const finalCallback = jest.fn();
    const debouncedFunction = debounce(callback, 1000, finalCallback);

    debouncedFunction();
    debouncedFunction();
    debouncedFunction();

    expect(callback).toHaveBeenCalledTimes(1);
  });
});
