/* eslint-disable @typescript-eslint/no-var-requires */
const fs = require('fs');
const path = require('path');

function createNewPackageFolder(newPackageName, componentName) {
  const newPackagePath = `./packages/${newPackageName}`;
  const srcPath = path.join(newPackagePath, 'src');

  // Create src folder and files
  if (!fs.existsSync(srcPath)) {
    fs.mkdirSync(srcPath);
  }

  const hasComponentName = !!componentName;

  const indexTsContent = hasComponentName
    ? `export { default as ${componentName} } from './${componentName}';`
    : '';

  const componentTsxContent = `import React from 'react';

function ${componentName}() {
  return (
    <div>Hello World</div>
  );
}

export default ${componentName};
  `;

  fs.writeFileSync(path.join(srcPath, 'index.ts'), indexTsContent);

  hasComponentName &&
    fs.writeFileSync(
      path.join(srcPath, `${componentName}.tsx`),
      componentTsxContent
    );

  // Create CHANGELOG.md
  fs.writeFileSync(path.join(newPackagePath, 'CHANGELOG.md'), '');

  // Create README.md
  fs.writeFileSync(path.join(newPackagePath, 'README.md'), '');

  // Create index.d.ts
  fs.writeFileSync(path.join(srcPath, 'index.d.ts'), '');

  // Create package.json
  const packageJsonContent = `{
  "name": "@mesh-tenant-multiverse-ui-common/${newPackageName}",
  "version": "0.0.0",
  "description": "",
  "keywords": [""],
  "license": "UNLICENSED",
  "main": "./dist/${newPackageName}.js",
  "types": "./dist/${newPackageName}.d.ts",
  "files": ["dist/*"],
  "scripts": {
    "lint": "eslint --ext .jsx,.js,.ts,.tsx ./src",
    "build": "node ../../tools/compile.js"
  },
  "dependencies": {},
  "repository": {
    "type": "git",
    "url": "ssh://git@bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library.git"
  },
  "peerDependencies": {
    "lodash": "^4.17.21",
    "react": "^18.x"
  }
}`;
  fs.writeFileSync(
    path.join(newPackagePath, 'package.json'),
    packageJsonContent
  );
}

module.exports = {
  createNewPackageFolder,
};
