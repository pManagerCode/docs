// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
import { AuthoriserBase } from './authoriserBase';
import {
  AuthorisationOutcome,
  Rule,
  RoleBaseAuthorisationModel,
  AuthorisationModel,
} from './types';
import {
  Roles,
  AUTHORISED_MSG,
  NOT_AUTHORISED_MSG,
  AgentActions,
  A014A6GalaxyViewOnlyActions,
  A014A6GalaxyServiceAndOperationsActions,
  A014A6GalaxyPacManagementActions,
} from './constants';

export class RoleBasedAuthoriser extends AuthoriserBase<RoleBaseAuthorisationModel> {
  // eslint-disable-next-line no-use-before-define
  private static instance: RoleBasedAuthoriser | null = null;

  private constructor() {
    super();
    if (RoleBasedAuthoriser.instance) {
      // eslint-disable-next-line no-constructor-return
      return RoleBasedAuthoriser.instance;
    }
    RoleBasedAuthoriser.instance = this;
  }

  public static getInstance(): RoleBasedAuthoriser {
    if (!RoleBasedAuthoriser.instance) {
      RoleBasedAuthoriser.instance = new RoleBasedAuthoriser();
    }
    return RoleBasedAuthoriser.instance;
  }

  public isUserAuthorised({
    resource,
    action,
    model,
  }: AuthorisationModel<RoleBaseAuthorisationModel>): AuthorisationOutcome {
    const result = this.authorise({
      resource,
      action,
      model,
    });

    return result
      ? { authorised: true, message: AUTHORISED_MSG }
      : { authorised: false, message: NOT_AUTHORISED_MSG };
  }

  protected addRule(rule: Rule<RoleBaseAuthorisationModel>) {
    this.ruleSet.push(rule);
  }

  loadRuleSet(): void {
    this.addRule(
      facts =>
        facts.model.roles
          .map(v => v.toLowerCase())
          .includes(Roles.AGENT.toLowerCase()) &&
        Object.values(AgentActions).includes(
          facts.action as unknown as AgentActions
        )
    );

    this.addRule(
      facts =>
        facts.model.roles
          .map(v => v.toLowerCase())
          .includes(Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS.toLowerCase()) &&
        Object.values(A014A6GalaxyServiceAndOperationsActions).includes(
          facts.action as unknown as A014A6GalaxyServiceAndOperationsActions
        )
    );

    this.addRule(
      facts =>
        facts.model.roles
          .map(v => v.toLowerCase())
          .includes(Roles.A014A6_GALAXY_VIEW_ONLY.toLowerCase()) &&
        Object.values(A014A6GalaxyViewOnlyActions).includes(
          facts.action as unknown as A014A6GalaxyViewOnlyActions
        )
    );

    this.addRule(
      facts =>
        facts.model.roles
          .map(v => v.toLowerCase())
          .includes(Roles.A014A6_GALAXY_PAC_MANAGEMENT.toLowerCase()) &&
        Object.values(A014A6GalaxyPacManagementActions).includes(
          facts.action as unknown as A014A6GalaxyPacManagementActions
        )
    );
  }
}
