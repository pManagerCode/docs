import {
  getOidcAccessTokenSlice,
  isLocalUrl,
  getConfig,
} from '@mep-ui/framework';
import { useSelector } from 'react-redux';
import {
  Resources,
  Actions,
  NOT_AUTHORISED_MSG,
  AUTHORISATION_REQUEST_SKIPPED,
  INVALID_AUTHORISATION_REQUEST,
} from './constants';
import type {
  AuthorisationOutcome,
  AuthorisationModel,
  RoleBaseAuthorisationModel,
} from './types';
import { RoleBasedAuthoriser } from './roleBasedAuthoriser';
import { parseRoleBasedModel } from './helper';

export const useAuthoriser = (
  resource: Resources,
  action: Actions
): AuthorisationOutcome => {
  return isUserAuthorised(resource, action);
};

export const isUserAuthorised = (
  resource: Resources,
  action: Actions
): AuthorisationOutcome => {
  let outcome = { authorised: false, message: NOT_AUTHORISED_MSG };
  let model: RoleBaseAuthorisationModel = { roles: [] };

  try {
    // use local configured role if available otherwise skip authorisation check (local only)
    if (isLocalUrl()) {
      const config = useSelector(getConfig);
      const configRoles = (config as { loggedInUserRole?: string | string[] })
        ?.loggedInUserRole;

      const configLoggedInUserRole = configRoles
        ? Array.isArray(configRoles)
          ? configRoles
          : [configRoles]
        : undefined;

      if (
        !(
          Array.isArray(configLoggedInUserRole) && configLoggedInUserRole.length
        )
      ) {
        return {
          authorised: true,
          message: AUTHORISATION_REQUEST_SKIPPED,
        };
      }
      model = { roles: configLoggedInUserRole };
    } else {
      const accessToken = useSelector(
        getOidcAccessTokenSlice
      ) as unknown as string;
      model = parseRoleBasedModel(accessToken);
    }
    if (!model.roles.length) {
      return {
        authorised: false,
        message: INVALID_AUTHORISATION_REQUEST,
      };
    }
    const context: AuthorisationModel<RoleBaseAuthorisationModel> = {
      resource,
      action,
      model,
    };
    const authoriser = RoleBasedAuthoriser.getInstance();
    outcome = authoriser.isUserAuthorised(context);
  } catch (error) {
    outcome = {
      authorised: false,
      message: error instanceof Error ? error.message : 'Unknown error',
    };
    console.error('Error in useAuthoriser:', error, outcome);
  }
  return outcome;
};
