# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.42.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.42.0...v1.42.1) (2025-01-08)

### 💥 Bug Fixes

- account summary ui fixes ([f389d5b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f389d5bf86bc3d63d70d522d98e9b6c7965bc135))
- account summary ui fixes JIRA: ART-37989 ([7dba215](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7dba215311397e1279074a8c8e7eb32dc9634531))

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

### 🚀 Features

- integrated storybook with webpack, added required config files ([b789dc6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b789dc66e72d9661796b48b977fe319ed1186ed4))

### 💥 Bug Fixes

- fixed the styling with mvaccount formatter story ([95a3935](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/95a39355f61a65bbc0fd37c0991fdc5d908c6e5a))

## [1.38.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.37.0...v1.38.0) (2024-12-13)

### 🚀 Features

- added error prop to Account Summary Prop | ART-14509 ([091da6d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/091da6d842cc4dd3ff8a959f7e98a42224dbab09))

## [1.37.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.36.0...v1.37.0) (2024-12-12)

### 🚀 Features

- minor code refactor | ART-14509 ([193773f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/193773f0b356303c61702bdfb99f94a1c30325de))

## [1.36.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.35.0...v1.36.0) (2024-12-12)

### 🚀 Features

- maccountsummary status prop added | ART-14496 ([3ed3116](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3ed3116be401823b15ac1ca12148d1948b449dda))
- merge conflicts resolved | ART-14496 ([700d2d8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/700d2d8bf9a0af89538380dfb53096d7210e3143))

## [1.35.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.10...v1.35.0) (2024-12-12)

### 🚀 Features

- add error message support to account summary | ART-14509 ([69e2dba](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/69e2dbaefd72811684499a0e2f6392198aeac21c))
- add error message support to account summary | ART-14509 ([4cc2c03](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4cc2c039bb29d4489c51ad0d6b26d54fd666f216))

## [1.34.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.33.3...v1.34.0) (2024-12-03)

### 🚀 Features

- adjust divider color ([04ee66b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/04ee66b81cd26151cd7088159e3cf6da030f37eb))
- created account summary component ([adad89f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/adad89f6641e26010ab9221447fcb98facb25bd6))
- updated code to follow best practice ([b22961c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b22961c892a6d68db3e30ba6ac399be11eec3350))
