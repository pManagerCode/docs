# MVCard Component

The `MVCard` component is a versatile card component built with React and styled using Tailwind CSS. It leverages the `@westpac/ui` library for grid layout and headings.

## Installation

To install the `MVCard` component, you can use npm:

```sh
npm install @mesh-tenant-multiverse-ui-common/mv-card

```


## Usage

To use the `MVCard` component, follow these steps:

1. Import the component in your file:

```jsx
import MVCard from '@mesh-tenant-multiverse-ui-common/mv-card';
```

2. Add the `MVCard` component to your JSX code:

```jsx
<MVCard title='accounts' template='wide' >{/* Content goes here */}</MVCard>
```

## Props

The `MVCard` component accepts the following props:

- `template` (optional): Specifies the maximum width and minimum width of the page card.

- `title` (required): Page title to be displayed inside page card.

## Example

Here's an updated example of how to use the `MVCard` component:

```jsx
import React from 'react';
import MVCard, { MVCardProps } from './MVCard';

const MyComponent = () => {
const props: MVCardProps = {
    title: 'Accounts',
    template: 'wide',
  };
  return (
    <MVCard {...props}>
      <p>This is an example card.</p>
    </MVCard>
  );
};

export default MyComponent;
```

That's it! You can now use the updated `MVCard` component in your page to display cards with consistent styling and layout.