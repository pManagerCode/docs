import * as React from 'react';
import { AgGridReactProps } from 'ag-grid-react';
import { ColDef } from 'ag-grid-community';

export type TableData = {
  [key: string]: unknown;
};

export type MVTablePropsType = AgGridReactProps & {
  noRowMessage: string;
  rowData: TableData[];
  defaultColumnDef: ColDef;
  height?: number;
};

export const MVTable: React.FC<MVTablePropsType>;

export const useSetAgGridLic: () => boolean;
