import { ColDef, IsFullWidthRowParams } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import { AgGridReact, AgGridReactProps } from 'ag-grid-react';
import React, { useRef } from 'react';
import { NoRowOverlay } from './_/NoRowOverlay';
import MVTableWrapper from './MVTableWrapper';

export type TableData = {
  [key: string]: unknown;
};

export type MVTablePropsType = AgGridReactProps & {
  noRowMessage: string;
  rowData: TableData[];
  defaultColumnDef: ColDef;
  height?: number;
};

const MVTable = ({
  rowData,
  noRowMessage,
  defaultColumnDef,
  height = 600,
  ...agGridProps
}: MVTablePropsType) => {
  const agGridRef = useRef<AgGridReact>(null);

  const isFullWidthRow = (params: IsFullWidthRowParams): boolean => {
    const { data } = params.rowNode;

    if (!data) return false;
    return !!data?.isLoading;
  };

  const defaultColDef: ColDef = {
    headerClass: 'default-header',
    cellClass: 'default-cell',
    wrapText: true,
    autoHeight: true,
    autoHeaderHeight: true,
    wrapHeaderText: true,
    ...defaultColumnDef,
  };

  const onBodyScroll = () => {
    if (agGridRef.current) {
      agGridRef.current.api.hidePopupMenu();
    }
  };

  return (
    <MVTableWrapper>
      <div className="w-full ag-theme-alpine" style={{ height: `${height}px` }}>
        <AgGridReact
          enableCellTextSelection
          suppressDragLeaveHidesColumns
          domLayout="normal"
          ref={agGridRef}
          rowData={rowData}
          animateRows
          rowSelection="single"
          isFullWidthRow={isFullWidthRow}
          suppressRowHoverHighlight
          suppressRowClickSelection
          suppressContextMenu
          defaultColDef={defaultColDef}
          noRowsOverlayComponent="noRowsOverlay"
          components={{
            noRowsOverlay: () => <NoRowOverlay noRowMessage={noRowMessage} />,
          }}
          {...agGridProps}
          onBodyScroll={onBodyScroll}
        />
      </div>
    </MVTableWrapper>
  );
};

export default MVTable;
