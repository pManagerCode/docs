# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.34.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.1...v1.34.2) (2024-12-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-loader
