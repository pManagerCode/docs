export { default as MVDetailSection } from './MVDetailSection';
export type { MVDetailSectionProps } from './MVDetailSection';
