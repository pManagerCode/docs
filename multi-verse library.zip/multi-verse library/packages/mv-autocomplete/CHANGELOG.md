# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.45.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.45.0...v1.45.1) (2025-01-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-autocomplete

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

### 🚀 Features

- integrated storybook with webpack, added required config files ([b789dc6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b789dc66e72d9661796b48b977fe319ed1186ed4))

## [1.23.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.23.0...v1.23.1) (2024-11-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-autocomplete

## [1.21.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-autocomplete

## [1.20.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.19.0...v1.20.0) (2024-11-06)

### 🚀 Features

- autocomplete component update | ART-24649 ([4229dd4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4229dd4459c558e41902df72e4a128cd2c5e3783))

## [1.17.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

### 🚀 Features

- amount and autocomplete components update| ART-24649 ([468ea8d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/468ea8d1a0a781ca5301f586eba605565964e297))
- autocomplete component package.json update | ART-24649 ([6614b7a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6614b7a48fe4532e9db3945f20794da0f007e6db))
- autocomplete component update | ART-24649 ([de6407f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/de6407f3ee16bf270897861191d619127472094a))
- update ref to mv-tiles | ART-24649 ([8b6714a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8b6714a965edc022a7702c86e40364d2c51ed5b9))
