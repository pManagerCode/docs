import React, { ReactNode } from 'react';
import {
  Control,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormTrigger,
} from 'react-hook-form';
import { ListOption } from '../../mv-autocomplete';

export type MVInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id: string;
  label: string;
  hintText?: string;
  validationRules?: RegisterOptions;
  maximumLength?: number;
  footerAddon?: ReactNode;
  withFooter?: boolean;
  inputType?: string;
  placeholder?: string;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
};

export const MVInputController: <T extends FieldValues>(
  props: MVInputControllerProps<T>
) => React.ReactElement;

export type MVTextareaControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id: string;
  label: string;
  hintText?: string;
  validationRules?: RegisterOptions;
  maximumLength?: number;
  footerAddon?: ReactNode;
  withFooter?: boolean;
  inputType?: string;
};

export const MVTextareaController: <T extends FieldValues>(
  props: MVTextareaControllerProps<T>
) => React.ReactElement;

export type MVCurrencyControllerProps<T extends FieldValues> = {
  id: string;
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  validationRules?: RegisterOptions;
  trigger: UseFormTrigger<T>;
  disabled?: boolean;
};

export const MVCurrencyController: <T extends FieldValues>(
  props: MVCurrencyControllerProps<T>
) => React.ReactElement;

export type MVSelectControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id?: string;
  label: string;
  validationRules?: RegisterOptions;
  options: Array<{ id: string; label: string; name: string }>;
  disabled?: boolean;
};

export const MVSelectController: <T extends FieldValues>(
  props: MVSelectControllerProps<T>
) => React.ReactElement;

export type MVSearchInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  autoFocus?: boolean;
  placeholder: string;
  validationRules?: RegisterOptions;
  listOptions: ListOption[];
  renderOption?: (option: unknown) => JSX.Element;
  renderValue?: (option: unknown) => string;
  noOptionsMessage?: string;
  defaultInputs?: unknown;
  header: string;
};

export const MVSearchInputController: <T extends FieldValues>(
  props: MVSearchInputControllerProps<T>
) => React.ReactElement;
