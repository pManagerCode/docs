# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.43.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.42.1...v1.43.0) (2025-01-09)

### 🚀 Features

- create MVDateRangePicker | ART-31841 ([1fa8399](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1fa83994e15d5da29d209be6ba3261c9a7151dab))
