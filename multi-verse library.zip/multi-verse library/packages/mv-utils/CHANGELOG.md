# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.45.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.44.1...v1.45.0) (2025-01-15)

### 🚀 Features

- added BSB formatter utility function | ART-28182 ([b7fdb74](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b7fdb745f8871612510803c3bce9ab0476c84252))

## [1.40.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.40.0...v1.40.1) (2024-12-19)

### 💥 Bug Fixes

- Revert APIError component | ART-31297 ([85f361c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/85f361c5ff8aa0befb13c1106afb73f21c5f10cb))

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.39.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.2...v1.39.3) (2024-12-17)

### 💥 Bug Fixes

- add throwAPIError function | ART-31297 ([66b0bdd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/66b0bdd382b031732d99889e8aeb943cc2fd2eab))
- unit test fixes | ART-31297 ([4044aa9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4044aa981540fe60a4b68c753f3357bf0ae82c36))

## [1.39.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.0...v1.39.1) (2024-12-16)

### 💥 Bug Fixes

- update export of APIError util | ART-31297 ([b2151f2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b2151f2d283a1072d0696d94e9e65a9add2c2631))

## [1.34.9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.8...v1.34.9) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.34.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.2...v1.34.3) (2024-12-06)

### 💥 Bug Fixes

- conditionally display the time zone JIRA: ART-31648 ([bcbbdb2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/bcbbdb2c4d6235c1c9b314c0d242b98606e29ed0))
- conditionally display the time zone JIRA: ART-31648 ([856b412](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/856b412a68774d973e0b7caa38e23cd7851c182f))

## [1.33.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.33.2...v1.33.3) (2024-12-03)

### 💥 Bug Fixes

- sonar cube major code smell | ART-31297 ([3fb6e20](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3fb6e20c667ff7f7b4362cef48cafcc6bceadb01))

## [1.33.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.32.1...v1.33.0) (2024-11-28)

### 🚀 Features

- add 2 more format helper functions JIRA: ART-14311 ([7a0019b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7a0019ba0fc7f5143f1729eb3e5307ef2319f6a1))
- format update JIRA: ART-14311 ([4af654a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4af654ad4197a44649bc33ad36f4f1acb44d5814))

## [1.32.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.32.0...v1.32.1) (2024-11-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.31.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.31.0...v1.31.1) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.28.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.27.0...v1.28.0) (2024-11-20)

### 🚀 Features

- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([cd17356](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cd17356957992cea05a1379d6b8df9d1081587e1))
- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([9e32d6b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9e32d6babeab138c926fad07090ae1854193c952))

## [1.27.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.26.0...v1.27.0) (2024-11-20)

### 🚀 Features

- postArrangementDetails API - add convertSydneyLocalTimeToUtc | ART-14302 ([623fc14](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/623fc14235f4d9edb87677e282103b9bdc9b696c))
- postArrangementDetails API - clean up | ART-14302 ([227d80d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/227d80d9a10bddab0b1efdbec1da3d59e65430fb))
- postArrangementDetails API - rollback | ART-14302 ([a50ec7b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a50ec7bbdf3ef406bc2588c6d3c6fe4323040ca3))

## [1.26.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.3...v1.26.0) (2024-11-20)

### 🚀 Features

- update utils currentcy controller | ART-24649 ([99d58b2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/99d58b2dc7a7b6df8efad9a99f46130b747aadec))

## [1.21.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.1...v1.21.2) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.21.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.20.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.20.0...v1.20.1) (2024-11-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.17.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

### 🚀 Features

- update ref to mv-tiles | ART-24649 ([8b6714a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8b6714a965edc022a7702c86e40364d2c51ed5b9))
- update ref with unit test and remove useless code | ART-24649 ([5932336](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5932336d90bab094a26a4fb17ce228622fb21aef))

## [1.12.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

### 🚀 Features

- add ag-grid | ART-15347 ([4d7a0ce](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4d7a0cec74717df4226dbbb8eaa4a9057c1d5168))

## [1.11.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))
