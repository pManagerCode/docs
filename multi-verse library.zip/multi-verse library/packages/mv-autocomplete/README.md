# @mesh-tenant-multiverse-ui-common/mv-autocomplete

## Purpose

The `MVAutoComplete` component provides a autocomplete input. It is built with GEL Next and styled using Tailwind CSS.

## Usage

To use the `MVAutoComplete` component, follow these steps:

1. Import the component in your file:

   ```jsx
   import MVAutoComplete from '@mesh-tenant-multiverse-ui-common/mv-autocomplete';
   ```

2. Add the `MVAutoComplete` component to your JSX code and provide the necessary props:

   ```jsx
   import React, { useRef } from 'react';
   import MVAutoComplete from '@mesh-tenant-multiverse-ui-common/mv-autocomplete';

     return (
       <MVAutoComplete/>
     );
   };

   export default MyComponent;
   ```

## Props

The `MVAutoComplete` component accepts the following props:

- `defaultInputValue` (required): default value of input;
- `listOptions` (required): data of options;
- `setSearchItem` (required): action to deal with search item;
- `onBlur` (required): actions when onblur;
- `isError` (required): Boolean to show the error message;
- `autoFocus?` (optional): Boolean to auto focus or not;
- `errorMessage` (required): error message content need to showing;
- `header` (required): header which need to showing;
- `helpText` (required): the help text need to showing ont top of the input;
- `renderOption?` (optional): (option` (required): any) => JSX.Element;
- `renderValue?` (optional): (option` (required): any) => string;
- `optionsMaxHeight?` (optional): number max height of options window;
- `isIconVisible?` (optional): Boolean to show the icon;
- `maxVisibleOptions?` (optional): number of max visible options showing;
- `defaultInputOption?` (optional): default input option showing;
- `placeholder?` (optional): placeholder to showing;
- `renderOptionOnHover?` (optional): showing option on mouse hover;

## Example

Here's an example of how to use the `MVAutoComplete` component:

```jsx
import React, { useRef } from 'react';
import MVAutoComplete from '@mesh-tenant-multiverse-ui-common/mv-autocomplete';

interface MVAutoCompleteProps {
  defaultInputValue: string;
  listOptions: ListOption[];
  setSearchItem: (value: any) => void;
  onBlur: () => void;
  isError: boolean;
  autoFocus?: boolean;
  errorMessage: string;
  header: string;
  helpText: string;
  renderOption?: (option: any) => JSX.Element;
  renderValue?: (option: any) => string;
  optionsMaxHeight?: number;
  isIconVisible?: boolean;
  maxVisibleOptions?: number;
  defaultInputOption?: ListOption;
  placeholder?: string;
  renderOptionOnHover?: (option: any) => JSX.Element;
}

const MyComponent = () => {


  return (
    <MVAutoComplete
        {...rest}
        defaultInputOption={defaultInputOption}
        defaultInputValue={
            value?.id && value?.name ? `${value.name} - ${value.id}` : ''
        }
        listOptions={listOptions}
        setSearchItem={(newValue: any) => {
            onChange(newValue);
            if (onChangeAccount) {
            onChangeAccount(newValue);
            }
        }}
        onBlur={() => {
            onBlur();
        }}
        isError={!!errorMessage}
        header={header}
        helpText={helpText}
        errorMessage={errorMessage}
        autoFocus={autoFocus}
        renderOption={renderOption}
        optionsMaxHeight={320}
        renderValue={renderValue}
        isIconVisible={isIconVisible}
        placeholder={placeholder}
        renderOptionOnHover={renderOptionOnHover}
    />
  );
};

export default MyComponent;
```
