# @mesh-tenant-multiverse-ui-common/mv-reacthookform

## Purpose

This package provides reusable form components built with React and `react-hook-form` for the Mesh Tenant Multiverse UI. These components include input controllers and textarea controllers that handle form validation, character limits, and other common form functionalities.

## Usage

### MVInputController

The `MVInputController` component is used to create controlled input fields with validation and character limit functionalities.

#### Props

- `fieldName`: The name of the field.
- `control`: The control object from `react-hook-form`.
- `errors`: The errors object from `react-hook-form`.
- `id`: The id of the input field.
- `label`: The label for the input field.
- `hintText` (optional): Hint text for the input field.
- `validationRules` (optional): Validation rules for the input field.
- `maximumLength` (optional): Maximum character length for the input field.
- `footerAddon` (optional): Additional content to be displayed in the footer.
- `withFooter` (optional): Flag to indicate if the footer should be displayed.
- `inputType` (optional): Type of input, e.g., 'ASCII printable'.

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVInputController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVInputController
        fieldName="username"
        control={control}
        errors={errors}
        id="username"
        label="Username"
        hintText="Enter your username"
        validationRules={{ required: 'Username is required' }}
        maximumLength={20}
        inputType="ASCII printable"
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### MVTextareaController

The `MVTextareaController` component is used to create controlled textarea fields with validation and character limit functionalities.

### Props

- `fieldName`: The name of the field.
- `control`: The control object from `react-hook-form`.
- `errors`: The errors object from `react-hook-form`.
- `id`: The id of the input field.
- `label`: The label for the input field.
- `hintText` (optional): Hint text for the input field.
- `validationRules` (optional): Validation rules for the input field.
- `maximumLength` (optional): Maximum character length for the input field.
- `footerAddon` (optional): Additional content to be displayed in the footer.
- `withFooter` (optional): Flag to indicate if the footer should be displayed.
- `inputType` (optional): Type of input, e.g., 'ASCII printable'.

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVTextareaController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVTextareaController
        fieldName="description"
        control={control}
        errors={errors}
        id="description"
        label="Description"
        hintText="Enter a description"
        validationRules={{ required: 'Description is required' }}
        maximumLength={200}
        inputType="ASCII printable"
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### MVCurrencyController

The `MVCurrencyController` component is used to create controlled input fields with validation and formatting of number of money input.

### Props

- `id` : The id of the input field.
- `fieldName` : The name of the field.
- `control` : The control object from.
- `errors` : The errors object from `react-hook-form`.
- `validationRules?` (optional): Validation rules for the input field.
- `trigger` : UseFormTrigger<T>;
- `disabled?` : boolean to disable input or not;

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVCurrencyController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVCurrencyController
        id="totalAmount"
        control={control}
        fieldName="totalAmount"
        errors={errors}
        trigger={trigger}
      />
    </form>
  );
}
```

### MVSelectController

The `MVSelectController` component is used to create controlled select fields.

### Props

- `id` : (Optional)The id of the input field.
- `label` : The label of the InputGroup.
- `fieldName` : The name of the field.
- `control` : The control object from `react-hook-form`.
- `errors` : The errors object from `react-hook-form`.
- `validationRules?` (optional): Validation rules for the select field.
- `options` : Options for select;
- `disabled?` : boolean to disable select or not;

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVSelectController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVSelectController
        options=[{id:"string", label:"string", name:"string"}, ...]
        control={control}
        label="Payment Method"
        fieldName="payment Method"
        errors={errors}
      />
    </form>
  );
}
```
### MVSearchInputController

The `MVSearchInputController` component is used to create controlled search input fields with validation and autocomplete functionalities.

### Props

- `fieldName`: The name of the field.
- `control`: The control object from `react-hook-form`.
- `errors`: The errors object from `react-hook-form`.
- `autoFocus?` (optional): Boolean to auto-focus the input field.
- `placeholder`: The placeholder for the input field.
- `validationRules?` (optional): Validation rules for the input field.
- `listOptions`: Array of options for the autocomplete.
- `renderOption?` (optional): Function to render each option.
- `renderValue?` (optional): Function to render the selected value.
- `noOptionsMessage?` (optional): Message to display when no options are available.
- `defaultInputs?` (optional): Default input values.

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVSearchInputController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVSearchInputController
        fieldName="search"
        control={control}
        errors={errors}
        placeholder="Search..."
        validationRules={{ required: 'Search is required' }}
        listOptions={[{ id: '1', label: 'Option 1' }, { id: '2', label: 'Option 2' }]}
        renderOption={option => <div>{option.label}</div>}
        renderValue={option => option.label}
        noOptionsMessage="No options available"
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```