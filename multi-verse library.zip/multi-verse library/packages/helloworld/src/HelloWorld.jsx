import React from 'react';
import { Well } from '@westpac/ui';
import PropTypes from 'prop-types';

function HelloWorld(props) {
  const { text } = props;
  return (
    <>
      <Well>What would you like to say?</Well>
      <Well>{text}</Well>
    </>
  );
}

HelloWorld.propTypes = {
  /**
   * Accepts a string which is displayed by the component
   */
  text: PropTypes.string,
};

HelloWorld.defaultProps = {
  text: 'Hello World',
};

export default HelloWorld;
