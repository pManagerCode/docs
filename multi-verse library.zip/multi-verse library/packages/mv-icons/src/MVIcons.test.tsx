/* eslint-disable react/react-in-jsx-scope */
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import MVIcons from './MVIcons';

describe('MVIcons', () => {
  it('renders Osko icon correctly', () => {
    render(<MVIcons name="Osko" />);

    const icon = screen.getByAltText('Osko');
    expect(icon).toBeInTheDocument();
    expect(icon).toHaveAttribute('height', '20');
    expect(icon).toHaveAttribute(
      'src',
      expect.stringContaining('data:image/svg+xml')
    );
  });

  it('renders PayTo icon correctly', () => {
    render(<MVIcons name="PayTo" />);
    const icon = screen.getByAltText('PayTo');
    expect(icon).toBeInTheDocument();
    expect(icon).toHaveAttribute(
      'src',
      expect.stringContaining('data:image/svg+xml')
    );
  });

  it('renders RightArrow icon correctly', () => {
    render(<MVIcons name="RightArrow" />);

    const icon = screen.getByAltText('RightArrow');
    expect(icon).toBeInTheDocument();
  });

  it('applies custom height and width correctly', () => {
    render(<MVIcons name="Osko" height={30} width={80} />);
    const icon = screen.getByAltText('Osko');
    expect(icon).toBeInTheDocument();
    expect(icon).toHaveAttribute('height', '30');
  });

  it('returns undefined for unknown icon name', () => {
    const { container } = render(<MVIcons name="UnknownIcon" />);
    expect(container.firstChild).toBeNull();
  });
});
