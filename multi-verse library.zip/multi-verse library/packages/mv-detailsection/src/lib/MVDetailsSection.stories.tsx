import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import MVDetailSection, { MVDetailSectionProps } from '../MVDetailSection';

// default export with component metadata
export default {
  tags: ['autodocs'],
  title: 'Components/MVDetailSection',
  component: MVDetailSection,
} as Meta<typeof MVDetailSection>;

// template for creating stories
const Template: StoryFn<typeof MVDetailSection> = args => (
  <MVDetailSection {...args} />
);

// sample data for the stories
const exampleData = [
  { label: 'Account Number', value: '1234567890' },
  { label: 'Account Type', value: 'Savings' },
  { label: 'Balance', value: '$2000' },
];

// default settings
export const Default = Template.bind({});
Default.args = {
  heading: 'Account Details',
  data: exampleData,
  withTopBorder: true,
  withBottomBorder: true,
} as MVDetailSectionProps;

// with link action
export const WithLinkAction = Template.bind({});
WithLinkAction.args = {
  heading: 'Account Details',
  data: exampleData,
  withTopBorder: true,
  withBottomBorder: true,
  linkAction: {
    text: 'View More',
    action: () => alert('Link action clicked'),
  },
} as MVDetailSectionProps;

// Story with no borders
export const NoBorders = Template.bind({});
NoBorders.args = {
  heading: 'Account Details',
  data: exampleData,
  withTopBorder: false,
  withBottomBorder: false,
} as MVDetailSectionProps;
