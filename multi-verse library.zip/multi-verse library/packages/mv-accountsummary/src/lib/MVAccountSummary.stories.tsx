import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import MVAccountSummary from '../MVAccountSummary';
import { MVAccountSummaryProps } from '../MVAccountSummary';

// default export with component metadata
export default {
  tags: ['autodocs'],
  title: 'Components/MVAccountSummary',
  component: MVAccountSummary,
} as Meta<typeof MVAccountSummary>;

// template for creating stories
const Template: StoryFn<typeof MVAccountSummary> = args => (
  <MVAccountSummary {...args} />
);

// default story
export const Default = Template.bind({});
Default.args = {
  header: <h2>Account Summary</h2>,
  items: [
    { title: 'Account Number', content: '1234567890' },
    { title: 'Account Type', content: 'Savings' },
    { title: 'Balance', content: '$10,000' },
  ],
} as MVAccountSummaryProps;

// story with custom widths
export const CustomWidths = Template.bind({});
CustomWidths.args = {
  header: <h2>Account Summary</h2>,
  items: [
    {
      title: 'Account Number',
      content: '1234567890',
      minWidth: 10,
      maxWidth: 20,
    },
    { title: 'Account Type', content: 'Savings', minWidth: 10, maxWidth: 20 },
    { title: 'Balance', content: '$10,000', minWidth: 10, maxWidth: 20 },
  ],
} as MVAccountSummaryProps;

// story with React nodes as content
export const ReactNodeContent = Template.bind({});
ReactNodeContent.args = {
  header: <h2>Account Summary</h2>,
  items: [
    { title: 'Account Number', content: <strong>1234567890</strong> },
    { title: 'Account Type', content: <em>Savings</em> },
    {
      title: 'Balance',
      content: <span style={{ color: 'green' }}>$10,000</span>,
    },
  ],
} as MVAccountSummaryProps;
