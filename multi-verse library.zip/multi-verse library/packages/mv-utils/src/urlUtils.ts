import { isStaffUrl, isLocalUrl } from '@mep-ui/framework';

const VALID_PARAMS = ['swimlane', 'systemTest', 'staffPortal'];

export const getURLParams = () => {
  const currentUrlParams = new URLSearchParams(window.location.search);
  const newUrlParams = new URLSearchParams();
  const entries = [...currentUrlParams.entries()];
  entries.forEach(entry => {
    if (VALID_PARAMS.includes(entry[0])) {
      newUrlParams.append(entry[0], entry[1]);
    }
  });
  return newUrlParams.size ? `?${newUrlParams.toString()}` : '';
};

export const getAppUrlWithParams = (
  newUrl: string,
  appName: string = 'galaxy'
): string => {
  const currentUrlParams = new URLSearchParams(window.location.search);
  const newUrlParams = new URLSearchParams();

  // Includes valid parameters
  currentUrlParams.forEach((value, key) => {
    if (VALID_PARAMS.includes(key)) {
      newUrlParams.append(key, value);
    }
  });
  const url = new URL(newUrl, window.location.href);
  const newSearchParams = new URLSearchParams(url.search);
  newSearchParams.forEach((value, key) => {
    newUrlParams.append(key, value);
  });

  // Includes new queryString
  const queryString = newUrlParams.toString();
  const queryStringPrefix = queryString ? `?${queryString}` : '';

  // Check galaxy ServerBasePath
  const currentUrl = new URL(window.location.href);
  const galaxyServerBasePath = currentUrl.pathname.startsWith(`/${appName}`)
    ? `/${appName}`
    : '';

  return `${url.origin}${galaxyServerBasePath}${url.pathname}${queryStringPrefix}`;
};

export const isStaffPortal = (): boolean => {
  const urlParams = new URLSearchParams(window.location.search);
  const isStaffPortalMode = urlParams.get('staffPortal') === 'true';
  return isStaffUrl() || (isLocalUrl() && isStaffPortalMode);
};

export const openNewTab = (url: string) => {
  window.open(`${url}${getURLParams()}`, '_blank', 'noopener=true');
};
