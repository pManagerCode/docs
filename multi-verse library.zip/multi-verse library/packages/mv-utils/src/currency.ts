export function formatCurrencyString(input: string): string {
  const num = Number(input);
  if (Number.isNaN(num) || input === '' || num <= 0) {
    return input;
  }

  const decimalPart = input.split('.')[1];

  if (decimalPart && decimalPart.length > 2) {
    return input;
  }

  const formattedNum = num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return formattedNum;
}

export function parseCurrencyString(input: string): string {
  return input.split(',').join('');
}
