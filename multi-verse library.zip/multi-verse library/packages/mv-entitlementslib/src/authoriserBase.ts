import { AuthorisationModel, AuthorisationOutcome, Rule } from './types';

export abstract class AuthoriserBase<T> {
  constructor() {
    this.loadRuleSet();
  }

  public authorise(context: AuthorisationModel<T>): boolean {
    return this.ruleSet.some(rule => rule(context));
  }

  public abstract isUserAuthorised({
    resource,
    action,
    model,
  }: AuthorisationModel<T>): AuthorisationOutcome;

  protected abstract loadRuleSet(): void;

  protected ruleSet: Rule<T>[] = [];
}
