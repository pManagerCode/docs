import * as React from 'react';

export type MVDetailSectionProps = {
  heading?: string;
  data: { label: string; value: string | JSX.Element | null | undefined }[];
  withTopBorder?: boolean;
  withBottomBorder?: boolean;
  linkAction?: {
    text: string;
    action: () => void;
  };
};

export const MVDetailSection: React.FC<MVDetailSectionProps>;
