import {
  NOT_AUTHORISED_MSG,
  AUTHORISED_MSG,
  Resources,
} from '../src/constants';
import { Actions } from '../src/constants';
import { useAuthoriser } from '../src/useAuthoriser';

const token =
  'eyJhbGciOiJSUzM4NCIsImtpZCI6Ikl5S0RfY1lUak5xTjlMVk1wN3dUM1ZBMnlhcyIsInBpLmF0bSI6IjI0YmoifQ.eyJzY29wZSI6ImdhbGF4eSBvcGVuaWQiLCJhdXRob3JpemF0aW9uX2RldGFpbHMiOltdLCJjbGllbnRfaWQiOiI5MzVhY2YxZi00MzUyLTQ2MGYtYjgwYy00NmQ1YzJjM2JhNDAiLCJpc3MiOiJodHRwczovL29uZWFjY2Vzcy5zaXQuYXV0aC5ucC53ZXN0cGFjZ3JvdXAuY29tIiwianRpIjoiRU40QzkxZzAxOVdMUkZoY1l2dGFpMzdJMDRVVzg2IiwiYnNiIjoiMDMyLTkwMCIsInN1YiI6IkwxOTU5MzQiLCJyb2xlIjpbIkEwMTRBNi1nYWxheHktc2VydmljZS1hbmQtb3BlcmF0aW9ucyIsIkEwMTRBNl9XMUNfQ0NNUF9lbmZvcmNlbWVudF9hY2xfc2l0Il0sImVtcGxveWVlSUQiOiJMMTk1OTM0Iiwid2JjX2lhbV91c2VyaWQiOiJMMTk1OTM0IiwiZ2l2ZW5fbmFtZSI6IkFzaHdpbmkiLCJmYW1pbHlfbmFtZSI6IkdvcmFudGxhIiwiZXhwIjoxNzIzNTMwMTExfQ.Hd0sElef0Irska0KPqT2FBeprUlRw6MzKszwkKcf5o-rEnI0y5HvhnD4Cnbn1pzGsYdHK6QRm7Ycr0y0P31kRXPoA7bu_B93ltyKeXqYpx70p6Pb371Uq3spNO8I_4mefexDv0zizZV2E7u2Btm_RZGZiFFuoJ48nnWQzxuguOQv3c5qVrUfmqrOBwPaRp5-5m6PyFZ_NK1Q0FQBlvQaz3dist7M7YF0fFzjz-x1GAGyZWHSVsWXIdhRUenoYlscJDWNCwF9KN4iuknlFXdtahXDu6N4SkOWBF0B-Wxch0_QAPpukMJNjU9Yc1VMhai6sBuARC0F3kDP-ZAZ36J9gQ';

// eslint-disable-next-line @typescript-eslint/no-unsafe-return
jest.mock('@mep-ui/framework', () => ({
  isLocalUrl: () => false,
}));

jest.mock('react-redux', () => ({
  useSelector: () => token,
}));

// valid request
describe('Authoriser test - ', () => {
  describe('when token contains A014A6-galaxy-view_only role (valid requests)', () => {
    test.skip('VIEW_ACCOUNTS should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_ACCOUNTS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test.skip('VIEW_TRANSACTIONS should return true ', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_TRANSACTIONS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test.skip('VIEW_PAYMENTS should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_PAYMENTS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test.skip('VIEW_ADVANCE_PAYMENT_TRANSACTIONS should return true', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW_ADVANCE_PAYMENT_TRANSACTIONS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });
  });

  // invalid request
  describe('when token contains A014A6-galaxy-view-only role (invalid requests)', () => {
    test.skip('INITIATE_PAYMENT should return false', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.INITIATE_PAYMENT
      );
      expect(authorised).toBe(false);
      expect(message).toEqual(NOT_AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test.skip('INITIATE_PAYMENT_RETURN should return false', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.INITIATE_PAYMENT_RETURN
      );
      expect(authorised).toBe(false);
      expect(message).toEqual(NOT_AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test.skip('VIEW should return false', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.VIEW
      );
      expect(authorised).toBe(false);
      expect(message).toEqual(NOT_AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test.skip('OVER_RIDE_CREDIT_INTEREST should return false', () => {
      const { authorised, message } = useAuthoriser(
        Resources.ACCOUNTS,
        Actions.OVER_RIDE_CREDIT_INTEREST
      );
      expect(authorised).toBe(false);
      expect(message).toEqual(NOT_AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });
  });
});
