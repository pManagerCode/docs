import * as React from 'react';

export type MVDateRangePickerProps = {
  heading?: string;
};

export const MVDateRangePicker: ({
  heading,
}: MVDateRangePickerProps) => React.ReactElement;
