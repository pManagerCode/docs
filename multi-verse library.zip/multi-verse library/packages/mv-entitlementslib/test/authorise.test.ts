import { RoleBasedAuthoriser } from '../src/roleBasedAuthoriser';
import { Roles, Resources, Actions } from '../src/constants';

const authoriser = RoleBasedAuthoriser.getInstance();
describe('Authorise - ', () => {
  // valid requests
  describe('when role is Agent (with valid requests)', () => {
    test('VIEW_ACCOUNTS should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ACCOUNTS,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(true);
      //  console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_TRANSACTIONS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_TRANSACTIONS,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_PAYMENTS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_PAYMENTS,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_ADVANCE_PAYMENT_TRANSACTIONS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ADVANCE_PAYMENT_TRANSACTIONS,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('INITIATE_PAYMENT should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });
  });

  // invalid requests
  describe('when role is Agent (with invalid requests)', () => {
    test('INITIATE_PAYMENT_RETURN should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT_RETURN,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('OVER_RIDE_CREDIT_INTEREST should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.OVER_RIDE_CREDIT_INTEREST,
        model: { roles: [Roles.AGENT] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });
  });
  // valid requests
  describe('when role is a014A6-galaxy-view-only (with valid requests)', () => {
    test('VIEW_ACCOUNTS should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ACCOUNTS,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_TRANSACTIONS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_TRANSACTIONS,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_PAYMENTS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_PAYMENTS,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_ADVANCE_PAYMENT_TRANSACTIONS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ADVANCE_PAYMENT_TRANSACTIONS,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });
  });

  // invalid request
  describe('when role is a014A6-galaxy-view-only (with invalid requests)', () => {
    test('INITIATE_PAYMENT should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('INITIATE_PAYMENT_RETURN should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT_RETURN,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('OVER_RIDE_CREDIT_INTEREST should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.OVER_RIDE_CREDIT_INTEREST,
        model: { roles: [Roles.A014A6_GALAXY_VIEW_ONLY] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });
  });

  // valid requests
  describe('when role is a014A6-galaxy-service-and-operations (with valid requests)', () => {
    test('VIEW_ACCOUNTS should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ACCOUNTS,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_TRANSACTIONS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_TRANSACTIONS,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_PAYMENTS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_PAYMENTS,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_ADVANCE_PAYMENT_TRANSACTIONS should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ADVANCE_PAYMENT_TRANSACTIONS,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('INITIATE_PAYMENT should return true', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('INITIATE_PAYMENT_RETURN should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT_RETURN,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });
  });
  // invalid request
  describe('when role is a014A6-galaxy-service-and-operations (with invalid requests)', () => {
    test('VIEW should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('OVER_RIDE_CREDIT_INTEREST should return false ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.OVER_RIDE_CREDIT_INTEREST,
        model: { roles: [Roles.A014A6_GALAXY_SERVICE_AND_OPERATIONS] },
      });
      expect(authorised).toBe(false);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });
  });

  // valid requests
  describe('when role is a014A6-galaxy-pac-management (with valid requests)', () => {
    test('VIEW should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });

    test('OVER_RIDE_CREDIT_INTEREST should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.OVER_RIDE_CREDIT_INTEREST,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      // console.log( `authorised: ${authorised as unknown as string}`);
    });
    // additional permissions from service and operations role
    test('VIEW_ACCOUNTS should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ACCOUNTS,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      //  //console.log(`authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_TRANSACTIONS should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_TRANSACTIONS,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      //  //console.log(`authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_PAYMENTS should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_PAYMENTS,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      //  //console.log(`authorised: ${authorised as unknown as string}`);
    });

    test('VIEW_ADVANCE_PAYMENT_TRANSACTIONS should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.VIEW_ADVANCE_PAYMENT_TRANSACTIONS,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      //  //console.log(`authorised: ${authorised as unknown as string}`);
    });

    test('INITIATE_PAYMENT should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      //  //console.log(`authorised: ${authorised as unknown as string}`);
    });

    test('INITIATE_PAYMENT_RETURN should return true ', () => {
      const authorised = authoriser.authorise({
        resource: Resources.ACCOUNTS,
        action: Actions.INITIATE_PAYMENT_RETURN,
        model: { roles: [Roles.A014A6_GALAXY_PAC_MANAGEMENT] },
      });
      expect(authorised).toBe(true);
      //  //console.log(`authorised: ${authorised as unknown as string}`);
    });
  });
});
