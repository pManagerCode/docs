import * as React from 'react';

export type ListOption = {
  name: string;
  id: string;
  entityName?: string;
  accountType?: string;
  payeeType?: string;
  domestic?: {
    accountName?: string;
  };
};

export interface MVAutoCompleteProps {
  defaultInputValue: string;
  listOptions: ListOption[];
  setSearchItem: (value: ListOption) => void;
  onBlur: () => void;
  isError: boolean;
  autoFocus?: boolean;
  errorMessage: string;
  header: string;
  helpText: string;
  renderOption?: (option: ListOption) => JSX.Element;
  renderValue?: (option: ListOption) => string;
  optionsMaxHeight?: number;
  isIconVisible?: boolean;
  maxVisibleOptions?: number;
  defaultInputOption?: ListOption;
  placeholder?: string;
  renderOptionOnHover?: (option: ListOption) => JSX.Element;
  isAdditionalError?: boolean;
}

export const MVAutoComplete: React.FC<MVAutoCompleteProps>;
