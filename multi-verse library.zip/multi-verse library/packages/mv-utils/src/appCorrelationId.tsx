import { useEffect } from 'react';
import { v4 as uuid } from 'uuid';

declare global {
  interface Window {
    setUserDataForAppd?: (data: { appCorrelationId: string }) => void;
  }
}

type SetAppCorrelationId = (id: string) => void;

export const useAppCorrelationId = (
  setAppCorrelationId: SetAppCorrelationId
) => {
  useEffect(() => {
    const newAppCorrelationId = uuid();
    setAppCorrelationId(newAppCorrelationId);
    if (window.setUserDataForAppd) {
      window.setUserDataForAppd({ appCorrelationId: newAppCorrelationId });
    }
  }, []);
};
