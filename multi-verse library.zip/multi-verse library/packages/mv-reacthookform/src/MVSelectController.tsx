/* eslint-disable react/prop-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable react/require-default-props */
import React from 'react';
import {
  Control,
  Controller,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
} from 'react-hook-form';
import { Select, InputGroup } from '@westpac/ui';

export type MVSelectControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id?: string;
  label: string;
  validationRules?: RegisterOptions;
  options: Array<{ id: string; label: string; name: string }>;
  disabled?: boolean;
};

function MVSelectController<T extends FieldValues>({
  label,
  fieldName,
  control,
  errors,
  validationRules = {},
  options,
  disabled = false,
}: MVSelectControllerProps<T>) {
  const errorMessage = (errors[fieldName]?.message as string) ?? '';

  const handleOnChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const currentValue = event.currentTarget.value;
    return currentValue;
  };

  return (
    <Controller
      name={fieldName}
      control={control as Control<FieldValues>}
      rules={validationRules}
      render={({ field: { onChange, value, ...rest } }) => (
        <InputGroup
          label={label}
          tag="fieldset"
          errorMessage={errorMessage}
          size="small"
          width={10}
        >
          <Select
            value={value}
            onChange={event => onChange(handleOnChange(event))}
            disabled={disabled}
            {...rest}
          >
            {options.map(option => (
              <option key={option.id} value={option.label}>
                {option.label}
              </option>
            ))}
          </Select>
        </InputGroup>
      )}
    />
  );
}

export default MVSelectController;
