import { mergeRefs } from '../src/ref';

describe('mergeRefs', () => {
  it('should call all function refs with the provided value', () => {
    const ref1 = jest.fn();
    const ref2 = jest.fn();
    const mergedRef = mergeRefs([ref1, ref2]);

    const value = { some: 'value' };
    mergedRef(value);

    expect(ref1).toHaveBeenCalledWith(value);
    expect(ref2).toHaveBeenCalledWith(value);
  });

  it('should set the current property of MutableRefObjects', () => {
    const ref1 = { current: null };
    const ref2 = { current: null };
    const mergedRef = mergeRefs([ref1, ref2]);

    const value = { some: 'value' };
    mergedRef(value);

    expect(ref1.current).toBe(value);
    expect(ref2.current).toBe(value);
  });

  it('should handle a mix of function refs and MutableRefObjects', () => {
    const ref1 = jest.fn();
    const ref2 = { current: null };
    const mergedRef = mergeRefs([ref1, ref2]);

    const value = { some: 'value' };
    mergedRef(value);

    expect(ref1).toHaveBeenCalledWith(value);
    expect(ref2.current).toBe(value);
  });

  it('should ignore null refs', () => {
    const ref1 = jest.fn();
    const ref2 = null;
    const mergedRef = mergeRefs([ref1, ref2]);

    const value = { some: 'value' };
    mergedRef(value);

    expect(ref1).toHaveBeenCalledWith(value);
  });
});
