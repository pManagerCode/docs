export const AUTHORISED_MSG = 'You are authorised.';
export const NOT_AUTHORISED_MSG = 'You do not have sufficient permission.';
export const AUTHORISATION_REQUEST_SKIPPED = 'Authorisation request skipped.';
export const INVALID_AUTHORISATION_REQUEST = 'Invalid authorisation request.';

/* enum values must be lower case */
// eslint-disable-next-line no-shadow
export enum Roles {
  AGENT = 'agent',
  A014A6_GALAXY_SERVICE_AND_OPERATIONS = 'A014A6-galaxy-service-and-operations',
  A014A6_GALAXY_VIEW_ONLY = 'A014A6-galaxy-view-only',
  A014A6_GALAXY_PAC_MANAGEMENT = 'A014A6-galaxy-pac-management',
}

// eslint-disable-next-line no-shadow
export enum AgentActions {
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
  INITIATE_PAYMENT = 'initiatePayment',
}

// eslint-disable-next-line no-shadow
export enum A014A6GalaxyViewOnlyActions {
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
}

// eslint-disable-next-line no-shadow
export enum A014A6GalaxyServiceAndOperationsActions {
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
  INITIATE_PAYMENT = 'initiatePayment',
  INITIATE_PAYMENT_RETURN = 'initiatePaymentReturn',
}

// eslint-disable-next-line no-shadow
export enum A014A6GalaxyPacManagementActions {
  VIEW = 'view',
  OVER_RIDE_CREDIT_INTEREST = 'overrideCreditInterest',
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
  INITIATE_PAYMENT = 'initiatePayment',
  INITIATE_PAYMENT_RETURN = 'initiatePaymentReturn',
  MANAGE_ACCOUNT_NAME = 'manageAccountName',
}

// eslint-disable-next-line no-shadow
export enum Resources {
  ACCOUNTS = 'account',
  TRANSACTIONS = 'transaction',
  CUSTOMER = 'customer',
  PAC = 'PAC',
}

// eslint-disable-next-line no-shadow
export enum Actions {
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  INITIATE_PAYMENT = 'initiatePayment',
  INITIATE_TRANSFER = 'initiateTransfer',
  INITIATE_PAYMENT_RETURN = 'initiatePaymentReturn',
  VIEW_BENEFICIARIES = 'viewBeneficiaries',
  OVER_RIDE_CREDIT_INTEREST = 'overrideCreditInterest',
  VIEW_DEFAULT_PERMISSIONS = 'viewDefaultPermissions',
  VIEW = 'view',
  OPEN_ACCOUNT = 'openAccount',
  CLOSE_ACCOUNT = 'closeAccount',
  BLOCK_ACCOUNT = 'blockAccount',
  UNBLOCK_ACCOUNT = 'unblockAccount',
  BLOCK_CUSTOMER = 'blockCustomer',
  UNBLOCK_CUSTOMER = 'unblockCustomer',
  AUTHORISE_PAYMENT = 'authorisePayment',
  AUTHORISE_TRANSFER = 'authoriseTransfer',
  CREATE_USER = 'createUser',
  AUTHORISE_USER = 'authoriseUser',
  MANAGE_ACCOUNT_NAME = 'manageAccountName',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
}
