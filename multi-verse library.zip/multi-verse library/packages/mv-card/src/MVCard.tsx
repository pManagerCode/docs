import { Grid, GridContainer, GridItem, Heading } from '@westpac/ui';
import React, { ReactNode } from 'react';

export type MVCardProps = {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  bottomDivider?: boolean;
  template?: 'wide' | 'narrow';
};

function MVCard({
  children,
  template,
  title,
  subtitle,
  bottomDivider,
}: MVCardProps) {
  return (
    <GridContainer>
      <Grid
        className={`${template === 'narrow' ? 'max-w-[720px]' : 'max-w-[1260px]'} bg-white border-t border-primary p-4 mx-auto !gap-0 min-w-[528px]`}
      >
      {
        title && (
          <GridItem span={12}>
          <Grid
            data-testid="title-grid"
            className={`gap-0 pb-2.5 ${bottomDivider ? 'border-b border-border' : ''}`}
          >
            <GridItem
              className="flex items-center justify-start"
              span={{ initial: 12, xsl: 7, sm: 6 }}
            >
              <Heading className="my-0" size={6} tag="h1">
                {title}
              </Heading>
            </GridItem>
            {subtitle && (
              <GridItem
                className="flex items-center justify-start sm:justify-end"
                span={{ initial: 12, xsl: 5, sm: 6 }}
              >
                <Heading
                  className="my-0 typography-body-11 text-muted"
                  size={8}
                  tag="h2"
                >
                  {subtitle}
                </Heading>
              </GridItem>
            )}
          </Grid>
        </GridItem>
        )
      }
        
        <GridItem span={12}>{children}</GridItem>
      </Grid>
    </GridContainer>
  );
}

MVCard.defaultProps = {
  template: 'wide',
  bottomDivider: true,
  subtitle: '',
};

export default MVCard;
