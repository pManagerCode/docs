# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.47.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.47.1...v1.47.2) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.47.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.46.2...v1.47.0) (2025-01-16)

### 🚀 Features

- mvSearchInputController updation | ART-28182 ([e03ffd7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e03ffd7e608cf49b852829191c5321aca1b13af1))
- searchInputController | ART-28182 ([3cb1781](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3cb1781b2278565c9ca5a0358b854ede11cdf85d))
- searchInputController update | ART-28182 ([1b80b65](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1b80b65e00d8fd6d1a00d2001a1e75b60ae7d2b5))

## [1.45.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.45.0...v1.45.1) (2025-01-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.34.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.4...v1.34.5) (2024-12-10)

### 💥 Bug Fixes

- correct behaviour of character limit on input and textarea | ART-30903 ([a9562b5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a9562b5160814942924fe102342bde16cf482ebc))

## [1.34.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.3...v1.34.4) (2024-12-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.30.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.30.2...v1.30.3) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.29.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.28.0...v1.29.0) (2024-11-20)

### 🚀 Features

- added xlarge | ART-15475 ([4c21d63](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4c21d6388cb7d743546a35600dde7fa83766d420))
- adding optional prop to mvinputcontroller |ART-15475 ([b9d0610](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b9d0610902f88d8ba527b3c4ced4626769a4b003))

## [1.26.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.3...v1.26.0) (2024-11-20)

### 🚀 Features

- update utils currency new update | ART-24649 ([b9ef76d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b9ef76d8b53507830fde23102ae7aef522167633))
- update utils currentcy controller | ART-24649 ([99d58b2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/99d58b2dc7a7b6df8efad9a99f46130b747aadec))

## [1.21.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.1...v1.21.2) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.21.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.17.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

### 🚀 Features

- amount and autocomplete components update| ART-24649 ([468ea8d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/468ea8d1a0a781ca5301f586eba605565964e297))
- currency controller update | ART-24649 ([26f04f9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/26f04f91c034c67caca6a9959b9bb7c5677ca230))
- update according to review feedback | ART-24649 ([d1637be](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d1637be774d8d1e034160074dde8800a3fd7148d))
- update ref to mv-tiles | ART-24649 ([8b6714a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8b6714a965edc022a7702c86e40364d2c51ed5b9))

## [1.12.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.11.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))
