import React, { SyntheticEvent } from 'react';
import { Button } from '@westpac/ui';
import { MoreHorizIcon } from '@westpac/ui/icon';
import { Column, IRowNode } from 'ag-grid-community';
import { TableData } from '../../MVTable';

export type ActionButtonPropsType = {
  api: {
    contextMenuFactory: {
      showMenu: (
        node: IRowNode<TableData>,
        column: Column<TableData>,
        value: string,
        event: SyntheticEvent
      ) => void;
    };
  };
  node: IRowNode<TableData>;
  column: Column<TableData>;
};

function ActionButton({ api, node, column }: ActionButtonPropsType) {
  const handleOnClick = (event: SyntheticEvent) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const newEvent = {
      ...event,
      clientX: rect.right - 129,
      clientY: rect.bottom,
    };
    api.contextMenuFactory.showMenu(node, column, '', newEvent);
  };

  const { rowIndex } = node;
  return (
    <Button
      look="faint"
      iconBefore={MoreHorizIcon}
      size="small"
      onClick={handleOnClick}
      iconSize="xsmall"
      data-testid={`ActionButton-${rowIndex}`}
    />
  );
}

export default ActionButton;
