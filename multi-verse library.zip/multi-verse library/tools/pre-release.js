/* eslint no-console: off */
const { exec } = require('child_process');

const { BRANCH_TYPE: branchType, BUILD_NUMBER: buildNumber } = process.env;
const shouldSkipPublishing = branchType === 'feature';

console.log(`\nCreating .env with variables...`);

const envVariables = `DOCS_SKIP=${shouldSkipPublishing}${
  buildNumber ? `\nDOCS_VERSION=${buildNumber}` : ``
}`;

console.log(envVariables);
exec(`echo "${envVariables}" > ./.env`);
