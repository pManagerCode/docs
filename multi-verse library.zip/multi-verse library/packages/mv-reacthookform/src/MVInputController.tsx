/* eslint-disable react/prop-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable react/require-default-props */
import { Input, InputGroup } from '@westpac/ui';
import { ReactNode, useMemo, useState } from 'react';
import {
  Control,
  Controller,
  FieldErrors,
  FieldPath,
  FieldPathValue,
  FieldValues,
  Noop,
  Path,
  RefCallBack,
  RegisterOptions,
} from 'react-hook-form';

type MVInputGroupProps<T extends FieldValues, TName extends FieldPath<T>> = {
  fieldName: Path<T>;
  value: FieldPathValue<T, TName>;
  onChange: (currentValue: string) => void;
  rest: {
    onBlur: Noop;
    disabled?: boolean;
    name: Path<T>;
    ref: RefCallBack;
  };
  errors: FieldErrors<T>;
  id: string;
  label: string;
  hintText?: string;
  maximumLength?: number;
  footerAddon?: ReactNode;
  withFooter?: boolean;
  inputType?: string;
  placeholder?: string;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
};

function MVInputGroup<T extends FieldValues, TName extends FieldPath<T>>({
  fieldName,
  value,
  onChange,
  rest,
  placeholder,
  errors,
  maximumLength,
  label,
  hintText,
  inputType,
  size,
  id
}: MVInputGroupProps<T, TName>) {
  const errorMessage = (errors[fieldName]?.message as string) ?? '';
  const maxlength = maximumLength ?? 35;
  const [charLeft, setCharLeft] = useState(
    value ? maxlength - value.length : maxlength
  );

  const handleOnChange = event => {
    let currentValue = event.currentTarget.value;
    if (currentValue.length > maxlength) {
      currentValue = currentValue.slice(0, maxlength);
    }

    if (inputType === 'ASCII printable') {
      currentValue = currentValue.replace(/[^\x20-\x7E]/g, '');
    }

    setCharLeft(maxlength - currentValue.length);

    return currentValue;
  };

  const counterText = useMemo(() => `${charLeft} remaining`, [charLeft]);

  return (
    <InputGroup
      label={label}
      errorMessage={errorMessage}
      supportingText={counterText}
      hint={hintText}
      size={size}
      instanceId={id}
    >
      <Input
        value={value}
        onChange={event => onChange(handleOnChange(event))}
        {...rest}
        placeholder={placeholder}
      />
    </InputGroup>
  );
}

export type MVInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id: string;
  label: string;
  hintText?: string;
  validationRules?: RegisterOptions;
  maximumLength?: number;
  footerAddon?: ReactNode;
  withFooter?: boolean;
  inputType?: string;
  placeholder?: string;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
};

function MVInputController<T extends FieldValues>({
  fieldName,
  control,
  validationRules = {},
  errors,
  id,
  label,
  hintText,
  maximumLength,
  footerAddon,
  withFooter,
  inputType,
  placeholder,
  size = 'small',
}: MVInputControllerProps<T>) {
  return (
    <Controller
      name={fieldName}
      // @ts-ignore
      control={control}
      rules={validationRules}
      render={({ field: { onChange, value, ...rest } }) => (
        <MVInputGroup
          onChange={onChange}
          value={value}
          rest={{ ...rest }}
          fieldName={fieldName}
          errors={errors}
          id={id}
          label={label}
          hintText={hintText}
          maximumLength={maximumLength}
          footerAddon={footerAddon}
          withFooter={withFooter}
          inputType={inputType}
          placeholder={placeholder}
          size={size}
        />
      )}
    />
  );
}

export default MVInputController;
