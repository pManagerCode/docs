import {
  currencyFormatter,
  formatBSB,
  formatCurrency,
  formatPercentage,
  formatToTwoDecimals,
  formatWithEllipsis,
  formatBSBFromAccNo,
} from '../src/format';

describe('Testing format', () => {
  describe('Test formatToTwoDecimals', () => {
    it('should return correct formatted number', () => {
      const string1 = '123.1';
      const string2 = '123123';
      const string3 = '123123.';
      expect(formatToTwoDecimals(string1)).toBe('123.10');
      expect(formatToTwoDecimals(string2)).toBe('123123.00');
      expect(formatToTwoDecimals(string3)).toBe('123123.00');
    });

    it('should throw an error for invalid input', () => {
      const string1 = '.';
      const string2 = 'string';
      expect(() => {
        formatToTwoDecimals(string1);
      }).toThrow('Input does not match the required format');
      expect(() => {
        formatToTwoDecimals(string2);
      }).toThrow('Input does not match the required format');
    });
  });

  describe('Test currencyFormatter', () => {
    it('should return number with correct format', () => {
      expect(currencyFormatter(1000)).toBe('1,000.00');
      expect(currencyFormatter(1000000)).toBe('1,000,000.00');
    });
  });

  describe('Test formatWithEllipsis', () => {
    it('should return string with ellipsis if it exceeds maxLength', () => {
      const str = 'This is a long string';
      const maxLength = 10;
      expect(formatWithEllipsis(str, maxLength)).toBe('This is a ...');
    });

    it('should return the same string if it does not exceed maxLength', () => {
      const str = 'Short';
      const maxLength = 10;
      expect(formatWithEllipsis(str, maxLength)).toBe('Short');
    });

    it('should return empty string if str is undefined', () => {
      const maxLength = 10;
      expect(formatWithEllipsis(undefined, maxLength)).toBe('');
    });

    it('should return empty string if maxLength is undefined', () => {
      const str = 'This is a long string';
      expect(formatWithEllipsis(str, undefined)).toBe('');
    });

    it('should return empty string if both str and maxLength are undefined', () => {
      expect(formatWithEllipsis(undefined, undefined)).toBe('');
    });
  });
});

describe('formatCurrency', () => {
  it('should format a number as currency', () => {
    expect(formatCurrency(1234)).toBe('$1,234');
    expect(formatCurrency(1000000)).toBe('$1,000,000');
    expect(formatCurrency(0)).toBe('$0');
  });

  it('should return an empty string for an empty input', () => {
    expect(formatCurrency('')).toBe('');
  });
});

describe('formatPercentage', () => {
  it('should format a number as a percentage', () => {
    expect(formatPercentage(0.1234)).toBe('12.34% p.a.');
    expect(formatPercentage(0.01)).toBe('1.00% p.a.');
    expect(formatPercentage(1)).toBe('100.00% p.a.');
  });
});

describe('formatBSB', () => {
  it('should format the ID with a hyphen after the third digit', () => {
    expect(formatBSB('123456', 3)).toBe('123-456');
    expect(formatBSB('789012', 2)).toBe('78-9012');
    expect(formatBSB('123', 3)).toBe('123-');
  });

  it('should handle IDs longer than 6 digits', () => {
    expect(formatBSB('123456789', 3)).toBe('123-456789');
  });
});

describe('formatBSBFromAccNo', () => {
  it('should return formatted BSB and account number when valid account name is provided', () => {
    const accountName = '123456 78901234';
    const result = formatBSBFromAccNo(accountName);
    expect(result).toBe('123-456 78901234');
  });

  it('should return empty string when account name is undefined', () => {
    const result = formatBSBFromAccNo(undefined);
    expect(result).toBe('');
  });

  it('should return empty string when account name is empty', () => {
    const result = formatBSBFromAccNo('');
    expect(result).toBe('');
  });

  it('should format BSB with specified length', () => {
    const accountName = '123456 78901234';
    const result = formatBSBFromAccNo(accountName, 2);
    expect(result).toBe('12-3456 78901234');
  });

  it('should handle account name with extra spaces', () => {
    const accountName = ' 123456  78901234 ';
    const result = formatBSBFromAccNo(accountName.trim());
    expect(result).toBe('123-456 78901234');
  });

  it('should handle account name with no space between BSB and account number', () => {
    const accountName = '12345678901234';
    const result = formatBSBFromAccNo(accountName);
    expect(result).toBe('123-456 78901234');
  });
});
