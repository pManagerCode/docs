import * as React from 'react';

export type MVAccountSummaryItem = {
  title: string;
  content: React.ReactNode | string;
  status?: string;
  statusColor?: 'success' | 'hero' | 'warning' | 'danger';
  maxWidth?: number;
  minWidth?: number;
};

export type MVAccountSummaryProps = {
  header?: React.ReactNode;
  items: MVAccountSummaryItem[];
  error?: React.ReactNode;
};

export const MVAccountSummary: React.FC<MVAccountSummaryProps>;
