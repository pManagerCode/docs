# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.46.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.46.0...v1.46.1) (2025-01-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils
