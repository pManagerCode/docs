# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/helloworld

## [1.8.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.7.2...v1.8.0) (2024-10-22)

### 🚀 Features

- update package name in library | ART-24650 ([1bd11b1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1bd11b1fc74f7b9fed08fee4a65aaca3517db2cf))

## [1.7.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.7.0...v1.7.1) (2024-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/helloworld

## [1.7.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.6.0...v1.7.0) (2024-10-22)

### 🚀 Features

- update hello world pacakge | ART-24650 ([5f89051](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5f8905112ccbbab228ee842eb83023bf59df8f10))

## [1.6.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.5.0...v1.6.0) (2024-10-21)

### 🚀 Features

- rename index file | ART-15321 ([d54bc3e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d54bc3e4f242c200a128267788df5ade6f52a7c0))

## [1.5.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.4.0...v1.5.0) (2024-10-21)

### 🚀 Features

- install helloworld comonent | ART-15321 ([9e1e197](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9e1e19785833d17e8b16e5f7f04e8a28d70c1282))

## [1.4.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.3.0...v1.4.0) (2024-10-21)

### 🚀 Features

- remove skip from UrlHelper, eslint configuration | ART-15321 ([f274ca1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f274ca1cee9662b11c0bf09029d79984cf40ac9d))

## 1.3.0 (2024-10-16)

### 🚀 Features

- initial mesh tenant multiverse ui common library | ART-15321 ([b8e295f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b8e295f45a7db6b3b143f3390ab287d2b538c615))
