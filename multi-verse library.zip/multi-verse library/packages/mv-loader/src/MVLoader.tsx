import React from 'react';
import { Grid, GridItem, ProgressIndicator } from '@westpac/ui';

type MVLoaderProps = {
  iconSize?: 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
  color?: 'white' | 'black';
};

function MVLoader({ iconSize = 'xlarge', color = 'white' }: MVLoaderProps) {
  return (
    <Grid className="fixed top-0 left-0 w-full h-full z-50 bg-black/50 grid place-items-center">
      <GridItem span={12}>
        <ProgressIndicator size={iconSize} color={color} />
      </GridItem>
    </Grid>
  );
}

export default MVLoader;
