/* eslint-disable @typescript-eslint/ban-ts-comment */
import { TextDecoder } from 'util';
import {
  decryptDataChunkFromString,
  generateKeyFromBase64,
} from '../src/crypto';

//@ts-ignore
global.TextDecoder = TextDecoder;

const importKeyMock = jest.fn();
const decryptMock = jest.fn();

//@ts-ignore
global.crypto = global.crypto || {};
//@ts-ignore
global.crypto.subtle = global.crypto.subtle || {};

global.crypto.subtle.importKey = importKeyMock;
global.crypto.subtle.decrypt = decryptMock;

const generateBase64 = (str: string) => Buffer.from(str).toString('base64');

describe('Testing crypto utilities', () => {
  describe('Testing generateKeyFromBase64', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('Should generate key from base64', async () => {
      const keyBase64 = Buffer.from('hello world').toString('base64');
      const KeyUsages = ['decrypt'];
      const mockImportedKey = {};
      importKeyMock.mockResolvedValue(mockImportedKey);

      //@ts-ignore
      const result = await generateKeyFromBase64(keyBase64, KeyUsages);
      expect(importKeyMock).toHaveBeenCalledWith(
        'pkcs8',
        expect.any(ArrayBuffer),
        {
          name: 'RSA-OAEP',
          hash: 'SHA-256',
        },
        true,
        KeyUsages
      );
      expect(result).toBe(mockImportedKey);
    });
  });

  describe('Testing generateKeyFromBase64', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('Should call decrypt data correctly', async () => {
      const base64String = `${generateBase64('hello')}|${generateBase64(
        'world'
      )}`;
      const privateKey = {} as CryptoKey;

      await decryptDataChunkFromString(base64String, privateKey);
      expect(decryptMock).toHaveBeenCalledTimes(2);
    });
  });
});
