import * as React from 'react';

export type MVLoaderProps = {
  iconSize?: 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
  color?: 'white' | 'black';
};

export const MVLoader: React.FC<MVLoaderProps>;
