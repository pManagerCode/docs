import {
  AUTHORISED_MSG,
  NOT_AUTHORISED_MSG,
  Resources,
} from '../src/constants';
import { Actions } from '../src/constants';
import { isUserAuthorised } from '../src/useAuthoriser';

const token =
  'eyJhbGciOiJSUzI1NiIsImtpZCI6ImtKbWhNdVRVc3VGLXo4bURySUduSld4QnI0NF9SUzI1NiIsInBpLmF0bSI6InMxOWMifQ.eyJzY29wZSI6WyJnYWxheHkiLCJvcGVuaWQiLCJwcm9maWxlIl0sImNsaWVudF9pZCI6IndkcHVpLWNjbXAtYmV0YSIsImlhdCI6MTcxMzE0MTE0OCwianRpIjoiRE5sNDR1UWo2YktxelhKSnhPMUVjQ1N2R3ZUS3c4QjciLCJ1c2VySWRTY2hlbWUiOiJDb3Jwb3JhdGVVc2VySWQiLCJhdWQiOiJndy1jdXN0b21lci5kZXYxLmFwaS53ZXN0cGFjLmNvbS5hdSIsInN1YiI6IndpbGwuc21pdGhAd2JjLmNvbSIsInJvbGUiOiJhZ2VudCIsInNlc3Npb25JbmRleCI6IjQ0NWExM2QyLWI5MTQtNDA5Mi1hZjg0LWRlMzk3YWY2MGEzYSIsInRyYWNrZXJJZCI6IjU3MmE2Y2E5LTkwMjgtNDQxOC04MDJmLWM1ZmQwMTBmMDUxZCIsImlzcyI6Imh0dHBzOi8vaW50ZXJuYWwuYTAwY2NjLmFwczIuZGV2MDQuYXdzZWx6Lndlc3RwYWMuY29tLmF1L2lkZW50aXR5IiwidXNlcklkIjoiNDYzNjIxMjAwOTkiLCJleHAiOjE3MTMxNDE0NDh9.OFrPe9fRQsvp4z0RWXpXLVESkvRSMUWtXmdam1jJ3QzfIV0VQ_4Bf-_1C7n47b0ACRWtM4JEMZcU_vUeDE3ZM4I64vKAPWk5oAsG6pzhXln0Yq5GKEpHWbSePmnRdimKcVuhQXCBvSC_c_kIMYh2rTwxs0DSsIHXJmrvY9jxKgYjIwfLzM2yiRe8TfiifL0vNxMYH8ue8wnnJZrpb3_YbxO9lpkrf8ZZfwdyWPizY_A4w1RWkikk1MYiKobxhZk5TehU5ZyskRRIsquAgUVClL_l0dQw4NMkC55iybMg-FE1CXreSxntmgBv9gyyFVhrihlzeNRuR1f3X_xDTaM6RZvfKx7C1wYjS3Ba5Tf2VL6KGtr0qFyJyzvZ7pWAVJev5npxulu1wRiNS4ExoCZiMjIwJLrsV6Zz8Ilj9RfTRPJZ7uHa9CzsV5VU4TYTlriqSqe_VguysnlGSKlfg7Bopgg4qXTGH9jRtAT8RIlHltofl5Hrz897vlkNudvBe9VKDeOakvd1fZIwwSB_Z1m1ARym11vRbH-QqdU718iSZkUa0wZwIBAnpmKEC-b7DqZCkRmUgpRI7y_X-qfuEhHlyD4CbyI80kEEAYVR85kDF9076ulV0RX5Qy2JQZAEUEs4e7Rk1wDb-CCAosPeATgKfMzmbARTTaaLAZfL-KMqnr8';

jest.mock('@mep-ui/framework', () => ({
  isLocalUrl: () => false,
}));

jest.mock('react-redux', () => ({
  useSelector: () => token,
}));

// valid request
describe('isUserAuthorised  ', () => {
  describe('when token contains Agent role (valid requests)', () => {
    test('VIEW_ACCOUNTS should return true', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.VIEW_ACCOUNTS
      );

      expect(message).toEqual(AUTHORISED_MSG);
      expect(authorised).toBe(true);
      console.log(
        `authorised: ${authorised as unknown as string}, message: ${message}`
      );
    });

    test('VIEW_TRANSACTIONS should return true ', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.VIEW_TRANSACTIONS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('VIEW_PAYMENTS should return true', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.VIEW_PAYMENTS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('VIEW_ADVANCE_PAYMENT_TRANSACTIONS should return true', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.VIEW_ADVANCE_PAYMENT_TRANSACTIONS
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });

    test('INITIATE_PAYMENT should return true', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.INITIATE_PAYMENT
      );
      expect(authorised).toBe(true);
      expect(message).toEqual(AUTHORISED_MSG);
      // console.log(   `authorised: ${authorised as unknown as string}, message: ${message}`    );
    });
  });

  // invalid request
  describe('when token contains Agent role (invalid requests)', () => {
    test('VIEW should return false', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.VIEW
      );
      expect(authorised).toBe(false);
      expect(message).toEqual(NOT_AUTHORISED_MSG);
      // console.log(  `authorised: ${authorised as unknown as string}, message: ${message}`  );
    });

    test('OVER_RIDE_CREDIT_INTEREST should return false', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.OVER_RIDE_CREDIT_INTEREST
      );
      expect(authorised).toBe(false);
      expect(message).toEqual(NOT_AUTHORISED_MSG);
      // console.log(  `authorised: ${authorised as unknown as string}, message: ${message}`  );
    });

    test('INITIATE_PAYMENT_RETURN should return false', () => {
      const { authorised, message } = isUserAuthorised(
        Resources.ACCOUNTS,
        Actions.INITIATE_PAYMENT_RETURN
      );
      expect(authorised).toBe(false);
      expect(message).toEqual(NOT_AUTHORISED_MSG);
      // console.log(  `authorised: ${authorised as unknown as string}, message: ${message}`   );
    });
  });
});
