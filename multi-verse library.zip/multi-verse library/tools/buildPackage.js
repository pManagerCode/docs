const fs = require('fs');
const path = require('path');
const webpack = require('webpack');
const { isEmpty } = require('lodash');

const cwd = process.cwd();
const pkg = require(`${cwd}/package.json`);

const pkgWebpackConfigPath = path.join(cwd, 'webpack.config');
const defaultWebpackConfigPath = path.join(__dirname, '../webpack.config');

const useDefaultWebpackConfig = !fs.existsSync(`${pkgWebpackConfigPath}.js`);

console.log(
  `\n\u001b[33;1mUsing ${
    useDefaultWebpackConfig ? '\u001b[4mdefault' : '\u001b[4mpackage specific'
  }\u001b[0m \u001b[33;1mbuild configuration\u001b[0m`
);

console.log(
  `Fetching \u001b[37;1mwebpack.config\u001b[0m @ \u001b[35;1m${
    useDefaultWebpackConfig ? defaultWebpackConfigPath : pkgWebpackConfigPath
  }\u001b[0m`
);

const config = useDefaultWebpackConfig
  ? require(defaultWebpackConfigPath)
  : require(pkgWebpackConfigPath);

if (!isEmpty(config)) {
  console.log(`\n\u001b[34mCompiling ${pkg.name} ...\u001b[0m`);

  config.externals = [
    ...config.externals,
    ...Object.keys(pkg.peerDependencies || {}),
  ];

  webpack(config, (err, stats) => {
    if (err || stats.hasErrors()) {
      console.error(
        `\n\u001b[31;1mCompilation of \u001b[37;1m${pkg.name}\u001b[0m \u001b[31;1mfailed\u001b[0m\n`,
        stats.toString({
          color: true,
        }),
        '\n'
      );
    } else {
      console.log(`\n\u001b[32;1m${pkg.name} compiled successfully\u001b[0m\n`);
    }
  });
}
