export const formatToTwoDecimals = (input: string) => {
  const num = Number(input);
  if (Number.isNaN(num)) {
    throw new Error('Input does not match the required format');
  }
  return num.toFixed(2);
};

export function currencyFormatter(
  num?: number,
  locale: string = 'en-US'
): string {
  if (num === undefined) {
    return '';
  }
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(num);
}

export const formatWithEllipsis = (
  str?: string,
  maxLength?: number
): string => {
  if (str === undefined || maxLength === undefined) {
    return '';
  }
  return str.length > maxLength ? `${str.substring(0, maxLength)}...` : str;
};

// Helper function to format currency like '0' to '$0', '1000' to '$1,000'
export const formatCurrency = (value: number | ''): string => {
  if (value === '') return '';
  return `$${value.toLocaleString('en-AU', { minimumFractionDigits: 0 })}`;
};

// Helper function to format percentage like '0.0285' to '2.85% p.a.'
export const formatPercentage = (rate: number): string => {
  return `${(rate * 100).toFixed(2)}% p.a.`;
};

// Helper function to format BSB like '123456' to '123-456'
export const formatBSB = (id: string, index: number) =>
  `${id.slice(0, index)}-${id.slice(index)}`;

/**
 * Formats the BSB and account number from a given account name.
 *
 * @param {string | undefined} accountNo - The account name containing BSB and account number.
 * @param {number} [bsbLength=3] - Optional parameter to specify the length for formatting BSB.
 * @returns {string} The formatted BSB and account number.
 */
export const formatBSBFromAccNo = (
  accountNo: string | undefined,
  bsbLength: number = 3
): string => {
  if (!accountNo) return '';
  const bsb = accountNo.slice(0, 6).trim();
  const accNo = accountNo.slice(6).trim();
  const formattedBsb = formatBSB(bsb, bsbLength);
  return `${formattedBsb} ${accNo}`.trim();
};
